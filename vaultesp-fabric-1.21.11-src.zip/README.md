# VaultESP

Storage, mob-spawner and ancient-debris ESP for **Minecraft 1.21.11** on **Fabric**, with a modern,
fully configurable ClickGUI. Client-side only, zero mixins, three draw calls per frame.

| | |
|---|---|
| Minecraft | `1.21.11` |
| Yarn mappings | `1.21.11+build.6` |
| Fabric Loader | `0.19.5` |
| Fabric API | `0.141.6+1.21.11` |
| Loom | `1.18-SNAPSHOT` (plugin id `net.fabricmc.fabric-loom-remap`) |
| Java | `21` |

## Building

```bash
# once, because a ZIP export cannot carry the signed gradle-wrapper.jar binary
gradle wrapper --gradle-version 8.14

# produces build/libs/vaultesp-1.0.0.jar
./gradlew build
```

Drop `build/libs/vaultesp-1.0.0.jar` **and** Fabric API into `.minecraft/mods`.
Ignore `vaultesp-1.0.0-dev.jar` and `vaultesp-1.0.0-sources.jar` - those are development artefacts.

IntelliJ IDEA / VS Code: open the folder as a Gradle project and let the IDE use its bundled Gradle
distribution, then run the `build` task. The `gradle/wrapper/gradle-wrapper.properties` in this repo
is already pinned to Gradle 8.14.

## Using it

| Action | Default |
|---|---|
| Open the ClickGUI | `RIGHT SHIFT` (also rebindable in vanilla controls) |
| Toggle a module from chat | `/vaultesp toggle StorageESP` |
| Change one setting from chat | `/vaultesp set AncientDebrisESP lineWidth 4.5` |
| Write the config | `/vaultesp save` (also happens on GUI close) |
| Reload the config | `/vaultesp reload` |
| Profiling counters | `/vaultesp stats` |

Config lives at `.minecraft/config/vaultesp.json` and is flat by design - every value is the exact
string the GUI writes and the chat command reads.

## Modules

### StorageESP (`Category.RENDER`)
Five independently switched families - **chests** (trapped chests included), **hoppers**,
**shulker boxes** (all seventeen colours), **barrels** and **ender chests**. Each one carries its
own ARGB colour (alpha included, so transparency is per-type), its own outline width in screen
pixels, and its own render mode: `Outline`, `Fill`, `Outline + Fill` or `Glow`. Module-wide settings
add render range, tracers, tracer width, distance fade and pulse.

### SpawnerFinder (`Category.WORLD`)
Outlines mob spawners through walls. Defaults to `Glow` mode at 3 px with tracers on, because
spawners are found in dark enclosed rooms where subtlety is useless. `Hide In Daylight` skips
spawners whose block light is above 7 - they cannot spawn anyway.

### AncientDebrisESP (`Category.WORLD`)
Outlines ancient debris for strip-mining. `smartYRange` clamps the section scan to `Y -8 .. 32`,
where debris can actually generate; `minY`/`maxY` then filter what gets drawn. `Dim Inside Lava`
halves the alpha while your head is in lava so the screen does not turn into noise.

### ClickGUI (`Category.CLIENT`)
Accent colour, GUI scale, background dim, animations, descriptions and keybind chips. Changing the
accent recolours the panel you are currently dragging.

### HUD (`Category.CLIENT`)
Compact overlay with live target counts per module, smoothed scan/render milliseconds and optional
scanner statistics (sections walked vs. sections rejected by palette filtering).

### Performance (`Category.CLIENT`)
The frame-time budget: scan radius, chunks scanned per tick, rescan interval, hard target cap,
frustum culling, and whether to skip the ESP while a screen is open.

## How the rendering works

* **`WorldRenderEvents.LAST`** - Fabric guarantees the camera view matrix is installed and every
  vanilla framebuffer write is finished, so disabling the depth test makes boxes read through
  solid rock without fighting water, weather or fabulous-mode compositing.
* **Camera-relative vertices** - no matrix multiply per vertex; the installed model-view matrix is
  reused untouched, and there is no float precision drift far from origin.
* **Ribbon outlines instead of `GL_LINES`** - `glLineWidth` is clamped to 1.0 on every modern
  core-profile driver, so thickness is real geometry. Each of the 12 edges becomes a camera-facing
  quad whose half-width is derived from the live projection matrix (`tan(fov/2) == 1 / m11`) and the
  scaled window height, which makes "outline width" a genuine screen-pixel setting at any distance.
  Eight camera-facing corner caps keep the ribbons joined at every angle.
* **Front-face-only fills** - one dot product per face halves the fill vertices and stops the
  colour washing out through itself.
* **Three batched buffers** - fills, outlines, tracers. One draw call each, no matter how many
  targets were found.
* **Allocation-free hot path** - targets live in fastutil `LongArrayList` / `ByteArrayList` as packed
  `BlockPos.asLong()` values plus a type byte, decoded with `BlockPos.unpackLongX/Y/Z`. Render
  commands come from a grow-only pool.

## How the scanning works

Chunks inside the scan radius are queued as a nearest-first ring spiral and drained at a fixed
budget per tick (`chunksPerTick`, default 6). Before reading a single block, each 16x16x16
`ChunkSection` is rejected twice:

1. `hasOnlyAir()` - skips every sky section above the terrain.
2. **palette rejection** - the section's block-state palette is asked whether it contains *any*
   target block. A 4096-block section of pure stone, deepslate or netherrack is discarded for the
   price of two or three palette lookups.

Results accumulate across the whole pass and are flattened into primitive arrays on commit, so the
renderer always sees a complete, consistent snapshot and never a half-built one. Everything runs on
the client thread; nothing allocates per block.

## Project layout

```
build.gradle                     net.fabricmc.fabric-loom-remap, split source sets, Java 21
gradle.properties                every pinned version
settings.gradle                  Fabric maven for plugin resolution
src/main/                        common (server-safe) source set
  java/dev/vaultesp/VaultESP.java
  resources/fabric.mod.json      entrypoints, depends, environment=client
  resources/assets/vaultesp/lang/en_us.json
src/client/                      client source set
  java/dev/vaultesp/client/
    VaultESPClient.java          keybind, config load, pipeline + command registration
    setting/                     Setting, Boolean, Number, Enum, Color
    module/                      Category, Module, ModuleManager
    modules/                     StorageESP, SpawnerFinder, AncientDebrisESP, ClickGui, Hud, Performance
    render/                      RenderMode, BoxRenderer, BlockScanner, ESPPipeline
    gui/                         Theme, ClickGuiScreen
    config/                      ConfigManager
    command/                     VaultCommand
```

## Notes

* Runtime dependencies: **Fabric API only**. fastutil, Gson and LWJGL ship with Minecraft.
* The mod is purely visual. It reads blocks the client has already received and draws boxes. It
  sends no packets and automates no interaction. Servers that ban X-ray-style rendering will still
  ban this - use it on your own worlds.

## License

MIT - see `LICENSE`.