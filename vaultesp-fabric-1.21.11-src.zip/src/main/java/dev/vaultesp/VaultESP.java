package dev.vaultesp;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Common entrypoint. VaultESP is a pure client mod - every feature lives in the
 * {@code client} source set and registers through {@link dev.vaultesp.client.VaultESPClient}.
 *
 * <p>This class deliberately holds no client imports so that {@code splitEnvironmentSourceSets()}
 * keeps the common jar server-safe.</p>
 */
public class VaultESP implements ModInitializer {

    public static final String MOD_ID = "vaultesp";
    public static final String MOD_NAME = "VaultESP";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_NAME);

    @Override
    public void onInitialize() {
        LOGGER.info("[{}] common initialiser loaded. Client features register in the client entrypoint.", MOD_NAME);
    }
}