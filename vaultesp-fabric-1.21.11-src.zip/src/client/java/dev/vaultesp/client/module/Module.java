package dev.vaultesp.client.module;

import dev.vaultesp.client.setting.Setting;
import net.minecraft.client.util.InputUtil;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * A toggleable feature with an ordered list of settings and an optional hotkey.
 *
 * <p>Subclasses declare settings as {@code public final} fields built through {@link #add(Setting)},
 * which both registers them for the GUI/config and keeps them reachable as typed fields for the
 * renderer - no string lookups in the hot path.</p>
 */
public abstract class Module {

    private final String name;
    private final String description;
    private final Category category;
    private final int accent;
    private final List<Setting<?>> settings = new ArrayList<>();

    private boolean enabled;
    private int bind = -1;
    private boolean listening;
    private long enabledAt;

    protected Module(String name, String description, Category category, int accent) {
        this.name = name;
        this.description = description;
        this.category = category;
        this.accent = accent;
    }

    protected final <S extends Setting<?>> S add(S setting) {
        settings.add(setting);
        return setting;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public Category getCategory() {
        return category;
    }

    public int getAccent() {
        return accent;
    }

    public List<Setting<?>> getSettings() {
        return Collections.unmodifiableList(settings);
    }

    public Setting<?> getSetting(String id) {
        for (Setting<?> setting : settings) {
            if (setting.getId().equalsIgnoreCase(id)) {
                return setting;
            }
        }
        return null;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public long getEnabledAt() {
        return enabledAt;
    }

    public void setEnabled(boolean value) {
        if (enabled == value) {
            return;
        }
        enabled = value;
        if (value) {
            enabledAt = System.currentTimeMillis();
            onEnable();
        } else {
            onDisable();
        }
    }

    public void toggle() {
        setEnabled(!enabled);
    }

    /** Called after the module flips to enabled. */
    protected void onEnable() {
    }

    /** Called after the module flips to disabled. */
    protected void onDisable() {
    }

    /** Runs once per client tick while the module is enabled. */
    public void onTick() {
    }

    public int getBind() {
        return bind;
    }

    public void setBind(int keyCode) {
        this.bind = keyCode;
    }

    public boolean isListening() {
        return listening;
    }

    public void setListening(boolean value) {
        this.listening = value;
    }

    public String getBindName() {
        if (bind < 0) {
            return "NONE";
        }
        try {
            return InputUtil.Type.KEYSYM.createFromCode(bind).getLocalizedText().getString().toUpperCase(Locale.ROOT);
        } catch (RuntimeException ignored) {
            return "KEY " + bind;
        }
    }

    /** Used by the GUI search field. */
    public boolean matches(String query) {
        if (query == null || query.isBlank()) {
            return true;
        }
        String needle = query.toLowerCase(Locale.ROOT);
        if (name.toLowerCase(Locale.ROOT).contains(needle)) {
            return true;
        }
        if (description.toLowerCase(Locale.ROOT).contains(needle)) {
            return true;
        }
        for (Setting<?> setting : settings) {
            if (setting.getId().toLowerCase(Locale.ROOT).contains(needle)
                    || setting.getName().toLowerCase(Locale.ROOT).contains(needle)) {
                return true;
            }
        }
        return false;
    }
}