package dev.vaultesp.client.module;

import dev.vaultesp.client.modules.AncientDebrisESPModule;
import dev.vaultesp.client.modules.ClickGuiModule;
import dev.vaultesp.client.modules.HudModule;
import dev.vaultesp.client.modules.PerformanceModule;
import dev.vaultesp.client.modules.SpawnerFinderModule;
import dev.vaultesp.client.modules.StorageESPModule;
import dev.vaultesp.client.setting.Setting;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Owns every module instance. Singleton, created once by the client entrypoint. */
public final class ModuleManager {

    private static final ModuleManager INSTANCE = new ModuleManager();

    private final List<Module> modules = new ArrayList<>();
    private final Map<String, Module> byName = new LinkedHashMap<>();

    private ModuleManager() {
        register(new StorageESPModule());
        register(new SpawnerFinderModule());
        register(new AncientDebrisESPModule());
        register(new ClickGuiModule());
        register(new HudModule());
        register(new PerformanceModule());
    }

    public static ModuleManager get() {
        return INSTANCE;
    }

    private void register(Module module) {
        modules.add(module);
        byName.put(module.getName().toLowerCase(Locale.ROOT), module);
    }

    public List<Module> all() {
        return Collections.unmodifiableList(modules);
    }

    public List<Module> byCategory(Category category) {
        List<Module> result = new ArrayList<>();
        for (Module module : modules) {
            if (module.getCategory() == category) {
                result.add(module);
            }
        }
        return result;
    }

    public Module byName(String name) {
        if (name == null) {
            return null;
        }
        Module exact = byName.get(name.toLowerCase(Locale.ROOT).trim());
        if (exact != null) {
            return exact;
        }
        String needle = name.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
        for (Map.Entry<String, Module> entry : byName.entrySet()) {
            if (entry.getKey().replaceAll("[^a-z0-9]", "").equals(needle)) {
                return entry.getValue();
            }
        }
        return null;
    }

    /** Type-safe lookup used by the renderer. Returns null only if the class was never registered. */
    @SuppressWarnings("unchecked")
    public <T extends Module> T get(Class<T> type) {
        for (Module module : modules) {
            if (type.isInstance(module)) {
                return (T) module;
            }
        }
        return null;
    }

    public int settingCount() {
        int total = 0;
        for (Module module : modules) {
            total += module.getSettings().size();
        }
        return total;
    }

    public List<Module> search(String query) {
        List<Module> result = new ArrayList<>();
        for (Module module : modules) {
            if (module.matches(query)) {
                result.add(module);
            }
        }
        return result;
    }

    public void resetAll() {
        for (Module module : modules) {
            for (Setting<?> setting : module.getSettings()) {
                setting.reset();
            }
            module.setEnabled(false);
            module.setBind(-1);
        }
    }
}