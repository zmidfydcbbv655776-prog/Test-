package dev.vaultesp.client.module;

/** ClickGUI panel grouping. Each category becomes one draggable panel. */
public enum Category {

    RENDER("Render", 0xFFFFB020),
    WORLD("World", 0xFF2FE0C0),
    CLIENT("Client", 0xFFFF5C7A);

    private final String label;
    private final int accent;

    Category(String label, int accent) {
        this.label = label;
        this.accent = accent;
    }

    public String getLabel() {
        return label;
    }

    /** Panel accent ARGB - overridden at runtime by the ClickGUI module's accent setting. */
    public int getAccent() {
        return accent;
    }
}