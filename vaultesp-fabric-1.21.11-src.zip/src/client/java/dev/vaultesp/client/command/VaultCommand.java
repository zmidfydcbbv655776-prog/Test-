package dev.vaultesp.client.command;

import com.mojang.brigadier.arguments.StringArgumentType;
import dev.vaultesp.client.config.ConfigManager;
import dev.vaultesp.client.gui.ClickGuiScreen;
import dev.vaultesp.client.module.Module;
import dev.vaultesp.client.module.ModuleManager;
import dev.vaultesp.client.render.BlockScanner;
import dev.vaultesp.client.render.ESPPipeline;
import dev.vaultesp.client.setting.Setting;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.client.MinecraftClient;
import net.minecraft.command.CommandRegistryAccess;
import net.minecraft.text.Text;

import java.util.Locale;

/**
 * {@code /vaultesp} - opens the GUI, toggles modules, edits single settings, saves, reloads and
 * dumps the scanner/render profiling counters.
 */
public final class VaultCommand {

    private VaultCommand() {
    }

    public static void register() {
        ClientCommandRegistrationCallback.EVENT.register(
                (dispatcher, registryAccess) -> dispatcher.register(ClientCommandManager.literal("vaultesp")
                        .executes(context -> open(context.getSource()))
                        .then(ClientCommandManager.literal("open")
                                .executes(context -> open(context.getSource())))
                        .then(ClientCommandManager.literal("toggle")
                                .then(ClientCommandManager.argument("module", StringArgumentType.word())
                                        .executes(context -> toggle(context.getSource(),
                                                StringArgumentType.getString(context, "module")))))
                        .then(ClientCommandManager.literal("set")
                                .then(ClientCommandManager.argument("module", StringArgumentType.word())
                                        .then(ClientCommandManager.argument("setting", StringArgumentType.word())
                                                .then(ClientCommandManager.argument("value", StringArgumentType.greedyString())
                                                        .executes(context -> set(context.getSource(),
                                                                StringArgumentType.getString(context, "module"),
                                                                StringArgumentType.getString(context, "setting"),
                                                                StringArgumentType.getString(context, "value")))))))
                        .then(ClientCommandManager.literal("save")
                                .executes(context -> save(context.getSource())))
                        .then(ClientCommandManager.literal("reload")
                                .executes(context -> reload(context.getSource())))
                        .then(ClientCommandManager.literal("stats")
                                .executes(context -> stats(context.getSource(), registryAccess)))));
    }

    private static int open(FabricClientCommandSource source) {
        MinecraftClient client = MinecraftClient.getInstance();
        client.send(() -> client.setScreen(ClickGuiScreen.INSTANCE));
        feedback(source, "Opening the VaultESP ClickGUI.");
        return 1;
    }

    private static int toggle(FabricClientCommandSource source, String name) {
        Module module = ModuleManager.get().byName(name);
        if (module == null) {
            feedback(source, "No module named '" + name + "'.");
            listModules(source);
            return 0;
        }
        module.toggle();
        ConfigManager.save();
        feedback(source, module.getName() + (module.isEnabled() ? " enabled." : " disabled."));
        return 1;
    }

    private static int set(FabricClientCommandSource source, String moduleName, String settingId, String value) {
        Module module = ModuleManager.get().byName(moduleName);
        if (module == null) {
            feedback(source, "No module named '" + moduleName + "'.");
            listModules(source);
            return 0;
        }
        Setting<?> setting = module.getSetting(settingId);
        if (setting == null) {
            feedback(source, moduleName + " has no setting '" + settingId + "'.");
            for (Setting<?> candidate : module.getSettings()) {
                source.sendFeedback(Text.literal("  - " + candidate.getId() + " = " + candidate.write()));
            }
            return 0;
        }
        setting.read(value);
        ConfigManager.save();
        feedback(source, moduleName + "." + settingId + " -> " + setting.write());
        return 1;
    }

    private static int save(FabricClientCommandSource source) {
        ConfigManager.save();
        feedback(source, "Config written to " + ConfigManager.file().getFileName() + ".");
        return 1;
    }

    private static int reload(FabricClientCommandSource source) {
        ConfigManager.load();
        ESPPipeline.get().scanner().clear();
        feedback(source, "Config reloaded and the scanner cache was flushed.");
        return 1;
    }

    private static int stats(FabricClientCommandSource source, CommandRegistryAccess registryAccess) {
        ESPPipeline pipeline = ESPPipeline.get();
        BlockScanner scanner = pipeline.scanner();
        feedback(source, "targets found " + scanner.size()
                + " | drawn " + pipeline.drawnCount()
                + " | chests " + scanner.count(BlockScanner.TYPE_CHEST)
                + " | hoppers " + scanner.count(BlockScanner.TYPE_HOPPER)
                + " | shulkers " + scanner.count(BlockScanner.TYPE_SHULKER)
                + " | spawners " + scanner.count(BlockScanner.TYPE_SPAWNER)
                + " | debris " + scanner.count(BlockScanner.TYPE_DEBRIS));
        source.sendFeedback(Text.literal(String.format(Locale.ROOT,
                "  scan %.2f ms/tick | render %.2f ms/frame | last pass %d ticks | sections %d walked / %d palette-rejected | %d blocks read",
                pipeline.scanMs(), pipeline.renderMs(), scanner.lastPassTicks(),
                scanner.sectionsScanned(), scanner.sectionsRejected(), scanner.blocksRead())));
        return 1;
    }

    private static void listModules(FabricClientCommandSource source) {
        StringBuilder builder = new StringBuilder("  modules: ");
        for (Module module : ModuleManager.get().all()) {
            builder.append(module.getName()).append(' ');
        }
        source.sendFeedback(Text.literal(builder.toString().trim()));
    }

    private static void feedback(FabricClientCommandSource source, String message) {
        source.sendFeedback(Text.literal("[VaultESP] " + message));
    }
}