package dev.vaultesp.client.gui;

import dev.vaultesp.client.config.ConfigManager;
import dev.vaultesp.client.module.Category;
import dev.vaultesp.client.module.Module;
import dev.vaultesp.client.module.ModuleManager;
import dev.vaultesp.client.modules.ClickGuiModule;
import dev.vaultesp.client.render.RenderMode;
import dev.vaultesp.client.setting.BooleanSetting;
import dev.vaultesp.client.setting.ColorSetting;
import dev.vaultesp.client.setting.EnumSetting;
import dev.vaultesp.client.setting.NumberSetting;
import dev.vaultesp.client.setting.Setting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * The ClickGUI. One draggable panel per {@link Category}, module rows that expand into their
 * settings, and a live search field.
 *
 * <p>Nothing here uses vanilla widgets: every row is hand drawn and hand hit-tested, which is what
 * lets the panel be recoloured, rescaled and re-themed at runtime without fighting
 * {@code ClickableWidget} layout. Panel positions, collapse state and every setting are written to
 * {@code config/vaultesp.json} when the screen closes.</p>
 *
 * <p>Open with <b>RIGHT SHIFT</b> (rebindable in vanilla controls) or <b>/vaultesp open</b>.</p>
 */
public class ClickGuiScreen extends Screen {

    public static final ClickGuiScreen INSTANCE = new ClickGuiScreen();

    private static final int[] PRESETS = {
            0xFFFFB020, 0xFFFF5C7A, 0xFF2FE0C0, 0xFF4CC4FF, 0xFFB6E84A,
            0xFFFF5CD7, 0xFFFFFFFF, 0xFF9AA7B5, 0xFF7B4DFF, 0xFFFF7A1A
    };

    private final List<Panel> panels = new ArrayList<>();

    private Panel dragPanel;
    private int dragOffsetX;
    private int dragOffsetY;
    private SliderWidget dragSlider;
    private Module bindingModule;
    private String search = "";
    private boolean searchFocused;
    private String hexDraft;
    private ColorSetting hexTarget;
    private float openProgress;
    private boolean laidOut;

    private String tooltip;
    private int tooltipX;
    private int tooltipY;

    private ClickGuiScreen() {
        super(Text.literal("VaultESP ClickGUI"));
    }

    // ---------------------------------------------------------------- lifecycle

    @Override
    protected void init() {
        super.init();
        if (!laidOut) {
            int x = Math.max(8, this.width / 2 - Theme.s(Panel.totalWidth() * 1.6f));
            int y = 34;
            for (Category category : Category.values()) {
                Panel panel = new Panel(category, x, y);
                panels.add(panel);
                x += Theme.s(Theme.PANEL_WIDTH) + Theme.s(14);
                if (x + Theme.s(Theme.PANEL_WIDTH) > this.width - 8) {
                    x = 12;
                    y += 220;
                }
            }
            laidOut = true;
        }
        openProgress = 0f;
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void close() {
        ConfigManager.save();
        super.close();
    }

    @Override
    public void removed() {
        bindingModule = null;
        hexTarget = null;
        ConfigManager.save();
    }

    public List<Panel> panels() {
        if (panels.isEmpty() && this.width > 0) {
            init();
        }
        return panels;
    }

    // ---------------------------------------------------------------- render

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        Theme.sync();
        ClickGuiModule gui = ModuleManager.get().get(ClickGuiModule.class);

        if (gui.animations.isOn()) {
            openProgress = Math.min(1f, openProgress + delta * 0.16f);
        } else {
            openProgress = 1f;
        }
        tooltip = null;

        int dimAlpha = (int) (gui.backgroundDim.get() * 255f * openProgress);
        if (dimAlpha > 0) {
            ctx.fill(0, 0, this.width, this.height, (dimAlpha << 24) | 0x05070A);
        }

        drawSearchBar(ctx, gui, mouseX, mouseY);

        String query = search.toLowerCase(Locale.ROOT);
        for (Panel panel : panels) {
            panel.render(ctx, this, mouseX, mouseY, delta, query);
        }

        drawFooter(ctx);

        if (tooltip != null && !tooltip.isEmpty()) {
            drawTooltip(ctx, tooltip, tooltipX, tooltipY);
        }
    }

    private void drawSearchBar(DrawContext ctx, ClickGuiModule gui, int mouseX, int mouseY) {
        int width = Theme.s(236);
        int height = Theme.s(20);
        int x = (this.width - width) / 2;
        int y = Theme.s(8);

        Theme.rect(ctx, x, y, width, height, Theme.PANEL_BG);
        Theme.outline(ctx, x, y, width, height, searchFocused ? Theme.accent : Theme.BORDER);
        Theme.rect(ctx, x, y, Theme.s(3), height, Theme.accent);

        String label = search.isEmpty() && !searchFocused ? "Search modules and settings" : search;
        int color = search.isEmpty() && !searchFocused ? Theme.TEXT_FAINT : Theme.TEXT;
        Theme.text(ctx, textRenderer, Theme.trim(textRenderer, label, width - Theme.s(34)),
                x + Theme.s(11), y + height / 2 - Theme.s(4), color);

        if (searchFocused && gui.animations.isOn() && (System.currentTimeMillis() / 420L) % 2L == 0L) {
            int caret = x + Theme.s(11) + textRenderer.getWidth(search);
            Theme.rect(ctx, caret, y + Theme.s(5), 1, height - Theme.s(10), Theme.accent);
        }

        int resetWidth = Theme.s(26);
        int resetX = x + width - resetWidth - Theme.s(3);
        boolean hoveredReset = inside(mouseX, mouseY, resetX, y + Theme.s(3), resetWidth, height - Theme.s(6));
        Theme.rect(ctx, resetX, y + Theme.s(3), resetWidth, height - Theme.s(6),
                hoveredReset ? Theme.mix(Theme.ROW_HOVER, Theme.accent, 0.25f) : Theme.FIELD_BG);
        Theme.text(ctx, textRenderer, "CLR", resetX + Theme.s(6), y + height / 2 - Theme.s(4),
                hoveredReset ? Theme.accent : Theme.TEXT_FAINT);

        if (!search.isEmpty()) {
            int matches = ModuleManager.get().search(search).size();
            Theme.text(ctx, textRenderer, matches + " hit" + (matches == 1 ? "" : "s"),
                    x + width + Theme.s(8), y + height / 2 - Theme.s(4), Theme.TEXT_FAINT);
        }
    }

    private void drawFooter(DrawContext ctx) {
        String hint = bindingModule != null
                ? "Press a key for " + bindingModule.getName() + " - ESC to clear"
                : hexTarget != null
                ? "Typing hex for " + hexTarget.getId() + " - ENTER to apply"
                : "LMB toggle / expand   drag sliders   RMB reset   wheel scrolls the hovered panel";
        int width = textRenderer.getWidth(hint) + Theme.s(14);
        int x = (this.width - width) / 2;
        int y = this.height - Theme.s(19);
        Theme.rect(ctx, x, y, width, Theme.s(14), Theme.withAlpha(Theme.PANEL_BG, 200));
        Theme.text(ctx, textRenderer, hint, x + Theme.s(7), y + Theme.s(3),
                bindingModule != null || hexTarget != null ? Theme.accent : Theme.TEXT_FAINT);
    }

    private void drawTooltip(DrawContext ctx, String text, int x, int y) {
        int width = textRenderer.getWidth(text) + Theme.s(12);
        int height = Theme.s(15);
        int px = Math.min(x + Theme.s(10), this.width - width - 2);
        int py = Math.min(y + Theme.s(12), this.height - height - 2);
        Theme.rect(ctx, px, py, width, height, 0xF50A0E14);
        Theme.outline(ctx, px, py, width, height, Theme.BORDER);
        Theme.rect(ctx, px, py, Theme.s(2), height, Theme.accent);
        Theme.text(ctx, textRenderer, text, px + Theme.s(7), py + Theme.s(4), Theme.TEXT_DIM);
    }

    void setTooltip(String text, int x, int y) {
        if (tooltip == null) {
            tooltip = text;
            tooltipX = x;
            tooltipY = y;
        }
    }

    static boolean inside(double mx, double my, int x, int y, int width, int height) {
        return mx >= x && mx < x + width && my >= y && my < y + height;
    }

    // ---------------------------------------------------------------- input

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (bindingModule != null) {
            bindingModule.setBind(button == 1 ? -1 : -2); // resolved in keyPressed for real keys
            bindingModule.setListening(false);
            bindingModule = null;
            return true;
        }

        // search bar
        int width = Theme.s(236);
        int height = Theme.s(20);
        int sx = (this.width - width) / 2;
        int sy = Theme.s(8);
        if (inside(mouseX, mouseY, sx, sy, width, height)) {
            int resetWidth = Theme.s(26);
            if (mouseX >= sx + width - resetWidth - Theme.s(3)) {
                search = "";
            } else {
                searchFocused = true;
            }
            return true;
        }
        searchFocused = false;

        // topmost panel first
        for (int i = panels.size() - 1; i >= 0; i--) {
            Panel panel = panels.get(i);
            if (panel.mouseClicked(this, mouseX, mouseY, button)) {
                panels.remove(i);
                panels.add(panel); // raise to front
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        dragPanel = null;
        dragSlider = null;
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (dragSlider != null) {
            dragSlider.drag(mouseX);
            return true;
        }
        if (dragPanel != null) {
            dragPanel.x = (int) (mouseX - dragOffsetX);
            dragPanel.y = (int) (mouseY - dragOffsetY);
            dragPanel.x = Math.max(0, Math.min(dragPanel.x, this.width - Theme.s(24)));
            dragPanel.y = Math.max(0, Math.min(dragPanel.y, this.height - Theme.s(16)));
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        for (int i = panels.size() - 1; i >= 0; i--) {
            if (panels.get(i).mouseScrolled(mouseX, mouseY, verticalAmount)) {
                return true;
            }
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (bindingModule != null) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_DELETE) {
                bindingModule.setBind(-1);
            } else {
                bindingModule.setBind(keyCode);
            }
            bindingModule.setListening(false);
            bindingModule = null;
            return true;
        }

        if (hexTarget != null) {
            if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
                hexTarget.read(hexDraft == null ? "" : hexDraft);
                hexTarget = null;
                hexDraft = null;
                return true;
            }
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
                hexTarget = null;
                hexDraft = null;
                return true;
            }
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE && hexDraft != null && !hexDraft.isEmpty()) {
                hexDraft = hexDraft.substring(0, hexDraft.length() - 1);
                return true;
            }
        }

        if (searchFocused) {
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                if (!search.isEmpty()) {
                    search = search.substring(0, search.length() - 1);
                }
                return true;
            }
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
                searchFocused = false;
                return true;
            }
        }

        if (keyCode == GLFW.GLFW_KEY_ESCAPE && !search.isEmpty() && !searchFocused) {
            search = "";
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (hexTarget != null) {
            if (isHexChar(chr)) {
                if (hexDraft == null) {
                    hexDraft = "";
                }
                if (hexDraft.length() < 9) {
                    hexDraft += chr;
                }
                return true;
            }
            return false;
        }
        if (searchFocused && chr >= ' ' && search.length() < 40) {
            search += chr;
            return true;
        }
        return super.charTyped(chr, modifiers);
    }

    private static boolean isHexChar(char c) {
        return (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F') || c == '#';
    }

    void setDragPanel(Panel panel, double mouseX, double mouseY) {
        dragPanel = panel;
        dragOffsetX = (int) (mouseX - panel.x);
        dragOffsetY = (int) (mouseY - panel.y);
    }

    void setDragSlider(SliderWidget slider) {
        dragSlider = slider;
    }

    void setBinding(Module module) {
        bindingModule = module;
        module.setListening(true);
    }

    void setHexTarget(ColorSetting setting) {
        hexTarget = setting;
        hexDraft = ColorSetting.toHex(setting.get()).substring(1);
    }

    boolean isHexTarget(ColorSetting setting) {
        return hexTarget == setting;
    }

    String hexDraft() {
        return hexDraft == null ? "" : hexDraft;
    }

    // ---------------------------------------------------------------- panel

    /** One draggable, collapsible, scrollable category panel. */
    public static final class Panel {

        final Category category;
        int x;
        int y;
        boolean collapsed;
        int scroll;
        private final List<ModuleRow> rows = new ArrayList<>();
        private int lastBodyHeight;
        private int lastBodyY;

        Panel(Category category, int x, int y) {
            this.category = category;
            this.x = x;
            this.y = y;
            for (Module module : ModuleManager.get().byCategory(category)) {
                rows.add(new ModuleRow(module));
            }
        }

        public Category getCategory() {
            return category;
        }

        public int getX() {
            return x;
        }

        public void setX(int value) {
            this.x = value;
        }

        public int getY() {
            return y;
        }

        public void setY(int value) {
            this.y = value;
        }

        public boolean isCollapsed() {
            return collapsed;
        }

        public void setCollapsed(boolean value) {
            this.collapsed = value;
        }

        static int totalWidth() {
            return Theme.PANEL_WIDTH;
        }

        void render(DrawContext ctx, ClickGuiScreen screen, int mouseX, int mouseY, float delta, String query) {
            int width = Theme.s(Theme.PANEL_WIDTH);
            int headerHeight = Theme.s(Theme.HEADER_HEIGHT);
            int accent = category == Category.CLIENT ? 0xFF4CC4FF : Theme.accent;

            Theme.rect(ctx, x, y, width, headerHeight, Theme.HEADER_BG);
            Theme.rect(ctx, x, y, Theme.s(3), headerHeight, accent);
            ctx.fillGradient(x + Theme.s(3), y, x + width, y + headerHeight, 0x22FFFFFF, 0x00FFFFFF);
            Theme.outline(ctx, x, y, width, headerHeight, Theme.HEADER_LINE);

            boolean headerHover = inside(mouseX, mouseY, x, y, width, headerHeight);
            Theme.text(ctx, screen.textRenderer, category.getLabel().toUpperCase(Locale.ROOT),
                    x + Theme.s(11), y + headerHeight / 2 - Theme.s(4), headerHover ? Theme.TEXT : Theme.TEXT_DIM);

            long active = rows.stream().filter(row -> row.module.isEnabled()).count();
            String count = active + "/" + rows.size();
            int countWidth = screen.textRenderer.getWidth(count);
            Theme.text(ctx, screen.textRenderer, count, x + width - countWidth - Theme.s(21),
                    y + headerHeight / 2 - Theme.s(4), active > 0 ? accent : Theme.TEXT_FAINT);

            String chevron = collapsed ? "+" : "-";
            int chevX = x + width - Theme.s(14);
            boolean chevHover = inside(mouseX, mouseY, chevX, y, Theme.s(14), headerHeight);
            Theme.rect(ctx, chevX, y + Theme.s(4), Theme.s(11), headerHeight - Theme.s(8),
                    chevHover ? Theme.ROW_HOVER : 0x00000000);
            Theme.text(ctx, screen.textRenderer, chevron, chevX + Theme.s(3), y + headerHeight / 2 - Theme.s(4),
                    chevHover ? accent : Theme.TEXT_FAINT);

            if (collapsed) {
                return;
            }

            // visible rows for the current query
            List<ModuleRow> visible = new ArrayList<>(rows.size());
            for (ModuleRow row : rows) {
                if (row.module.matches(query)) {
                    visible.add(row);
                }
            }
            if (visible.isEmpty()) {
                int emptyHeight = Theme.s(20);
                Theme.rect(ctx, x, y + headerHeight, width, emptyHeight, Theme.SETTINGS_BG);
                Theme.text(ctx, screen.textRenderer, "no matches", x + Theme.s(11),
                        y + headerHeight + Theme.s(6), Theme.TEXT_FAINT);
                Theme.outline(ctx, x, y + headerHeight, width, emptyHeight, Theme.SETTINGS_LINE);
                return;
            }

            int content = 0;
            for (ModuleRow row : visible) {
                content += row.height(screen, query);
            }
            int maxBody = Theme.s(Theme.BODY_MAX);
            int bodyHeight = Math.min(content, maxBody);
            scroll = Math.max(0, Math.min(scroll, Math.max(0, content - bodyHeight)));

            lastBodyY = y + headerHeight;
            lastBodyHeight = bodyHeight;

            Theme.rect(ctx, x, lastBodyY, width, bodyHeight, Theme.PANEL_BG);
            Theme.outline(ctx, x, lastBodyY, width, bodyHeight, Theme.BORDER);

            ctx.enableScissor(x + 1, lastBodyY + 1, x + width - 1, lastBodyY + bodyHeight - 1);
            int rowY = lastBodyY - scroll;
            for (ModuleRow row : visible) {
                row.render(ctx, screen, x, rowY, width, mouseX, mouseY, delta, query);
                rowY += row.height(screen, query);
            }
            ctx.disableScissor();

            if (content > bodyHeight) {
                int trackHeight = bodyHeight - Theme.s(4);
                int thumbHeight = Math.max(Theme.s(12), trackHeight * bodyHeight / content);
                int thumbY = lastBodyY + Theme.s(2) + (content - bodyHeight == 0 ? 0
                        : scroll * (trackHeight - thumbHeight) / (content - bodyHeight));
                Theme.rect(ctx, x + width - Theme.s(3), lastBodyY + Theme.s(2), Theme.s(2), trackHeight, 0xFF131A23);
                Theme.rect(ctx, x + width - Theme.s(3), thumbY, Theme.s(2), thumbHeight, Theme.mix(Theme.BORDER, accent, 0.5f));
            }
        }

        boolean mouseClicked(ClickGuiScreen screen, double mouseX, double mouseY, int button) {
            int width = Theme.s(Theme.PANEL_WIDTH);
            int headerHeight = Theme.s(Theme.HEADER_HEIGHT);

            if (inside(mouseX, mouseY, x, y, width, headerHeight)) {
                if (button == 0 && inside(mouseX, mouseY, x + width - Theme.s(14), y, Theme.s(14), headerHeight)) {
                    collapsed = !collapsed;
                } else if (button == 0) {
                    screen.setDragPanel(this, mouseX, mouseY);
                } else if (button == 1) {
                    collapsed = !collapsed;
                }
                return true;
            }

            if (collapsed) {
                return false;
            }
            if (!inside(mouseX, mouseY, x, lastBodyY, width, lastBodyHeight)) {
                return false;
            }

            int rowY = lastBodyY - scroll;
            for (ModuleRow row : rows) {
                if (!row.module.matches(screen.search.toLowerCase(Locale.ROOT))) {
                    continue;
                }
                int height = row.height(screen, screen.search.toLowerCase(Locale.ROOT));
                if (inside(mouseX, mouseY, x, rowY, width, height)) {
                    row.mouseClicked(screen, mouseX, mouseY, button, x, rowY, width);
                    return true;
                }
                rowY += height;
            }
            return true;
        }

        boolean mouseScrolled(double mouseX, double mouseY, double amount) {
            int width = Theme.s(Theme.PANEL_WIDTH);
            if (!inside(mouseX, mouseY, x, y, width, lastBodyY + lastBodyHeight - y)) {
                return false;
            }
            scroll = Math.max(0, scroll - (int) (amount * Theme.s(18)));
            return true;
        }
    }

    // ---------------------------------------------------------------- module row

    /** A module header plus its expanded settings. */
    static final class ModuleRow {

        final Module module;
        boolean expanded;
        private ColorSetting openColor;
        private float hover;
        private int lastX;
        private int lastY;
        private int lastWidth;

        ModuleRow(Module module) {
            this.module = module;
        }

        int height(ClickGuiScreen screen, String query) {
            int height = Theme.s(Theme.MODULE_HEIGHT);
            if (!expanded && !module.matches(query) && !query.isEmpty()) {
                // search hits on a setting name auto-expand so the match is actually visible
            }
            if (expanded || (!query.isEmpty() && module.matches(query))) {
                for (Setting<?> setting : module.getSettings()) {
                    if (!setting.isVisible()) {
                        continue;
                    }
                    if (setting instanceof ColorSetting color && openColor == color) {
                        height += Theme.s(Theme.COLOR_HEIGHT + Theme.COLOR_EDITOR_HEIGHT);
                    } else if (setting instanceof NumberSetting) {
                        height += Theme.s(Theme.SLIDER_HEIGHT);
                    } else if (setting instanceof BooleanSetting || setting instanceof EnumSetting<?>) {
                        height += Theme.s(Theme.TOGGLE_HEIGHT);
                    } else {
                        height += Theme.s(Theme.COLOR_HEIGHT);
                    }
                }
                height += Theme.s(Theme.TOGGLE_HEIGHT); // keybind row
                if (screen != null && !module.getDescription().isEmpty()) {
                    height += Theme.s(12);
                }
            }
            return height;
        }

        void render(DrawContext ctx, ClickGuiScreen screen, int x, int y, int width,
                    int mouseX, int mouseY, float delta, String query) {
            lastX = x;
            lastY = y;
            lastWidth = width;

            int headerHeight = Theme.s(Theme.MODULE_HEIGHT);
            boolean hovered = inside(mouseX, mouseY, x, y, width, headerHeight);
            ClickGuiModule gui = ModuleManager.get().get(ClickGuiModule.class);
            if (gui.animations.isOn()) {
                hover += ((hovered ? 1f : 0f) - hover) * Math.min(1f, delta * 0.35f);
            } else {
                hover = hovered ? 1f : 0f;
            }

            boolean open = expanded || (!query.isEmpty() && module.matches(query));
            int background = module.isEnabled() ? Theme.ROW_OPEN : Theme.PANEL_BG;
            Theme.rect(ctx, x, y, width, headerHeight, Theme.mix(background, Theme.ROW_HOVER, hover * 0.8f));

            if (module.isEnabled()) {
                Theme.rect(ctx, x, y, Theme.s(2), headerHeight, module.getAccent());
            }

            int accent = module.isEnabled() ? module.getAccent() : Theme.TEXT_DIM;
            Theme.text(ctx, screen.textRenderer, Theme.trim(screen.textRenderer, module.getName(), width - Theme.s(58)),
                    x + Theme.s(9), y + headerHeight / 2 - Theme.s(4), module.isEnabled() ? Theme.TEXT : accent);

            if (gui.showKeybinds.isOn() && module.getBind() >= 0) {
                String bind = module.getBindName();
                int bindWidth = screen.textRenderer.getWidth(bind) + Theme.s(6);
                int bx = x + width - Theme.s(30) - bindWidth;
                Theme.rect(ctx, bx, y + Theme.s(5), bindWidth, headerHeight - Theme.s(10), Theme.FIELD_BG);
                Theme.outline(ctx, bx, y + Theme.s(5), bindWidth, headerHeight - Theme.s(10), Theme.BORDER);
                Theme.text(ctx, screen.textRenderer, bind, bx + Theme.s(3), y + headerHeight / 2 - Theme.s(4), Theme.TEXT_FAINT);
            }

            // toggle switch
            int swWidth = Theme.s(24);
            int swHeight = Theme.s(12);
            int sx = x + width - swWidth - Theme.s(22);
            int sy = y + (headerHeight - swHeight) / 2;
            int on = Theme.withAlpha(module.getAccent(), 60);
            Theme.rect(ctx, sx, sy, swWidth, swHeight, module.isEnabled() ? on : Theme.SWITCH_OFF_BG);
            Theme.outline(ctx, sx, sy, swWidth, swHeight, module.isEnabled() ? module.getAccent() : Theme.SWITCH_OFF_BORDER);
            int knob = Theme.s(8);
            int kx = module.isEnabled() ? sx + swWidth - knob - Theme.s(2) : sx + Theme.s(2);
            Theme.rect(ctx, kx, sy + Theme.s(2), knob, knob,
                    module.isEnabled() ? module.getAccent() : Theme.SWITCH_OFF_KNOB);

            // expand chevron
            String chevron = open ? "v" : ">";
            Theme.text(ctx, screen.textRenderer, chevron, x + width - Theme.s(13),
                    y + headerHeight / 2 - Theme.s(4), hovered ? Theme.TEXT : Theme.TEXT_FAINT);

            ctx.fill(x, y + headerHeight - 1, x + width, y + headerHeight, Theme.SETTINGS_LINE);

            if (hovered && gui.showDescriptions.isOn() && !module.getDescription().isEmpty()) {
                screen.setTooltip(Theme.trim(screen.textRenderer, module.getDescription(), 340), mouseX, mouseY);
            }

            if (!open) {
                return;
            }

            int cursor = y + headerHeight;
            Theme.rect(ctx, x, cursor, width, height(screen, query) - headerHeight, Theme.SETTINGS_BG);
            Theme.rect(ctx, x + Theme.s(Theme.INDENT), cursor, 1, height(screen, query) - headerHeight, Theme.SETTINGS_LINE);

            // description line
            if (!module.getDescription().isEmpty()) {
                int textWidth = width - Theme.s(Theme.INDENT) - Theme.s(14);
                String text = Theme.trim(screen.textRenderer, module.getDescription(), textWidth);
                Theme.text(ctx, screen.textRenderer, text, x + Theme.s(Theme.INDENT + 5), cursor + Theme.s(3), Theme.TEXT_FAINT);
                cursor += Theme.s(12);
            }

            for (Setting<?> setting : module.getSettings()) {
                if (!setting.isVisible()) {
                    continue;
                }
                if (setting instanceof BooleanSetting bool) {
                    cursor = renderBoolean(ctx, screen, bool, x, cursor, width, mouseX, mouseY);
                } else if (setting instanceof NumberSetting number) {
                    cursor = renderSlider(ctx, screen, number, x, cursor, width, mouseX, mouseY);
                } else if (setting instanceof EnumSetting<?> enumeration) {
                    cursor = renderEnum(ctx, screen, enumeration, x, cursor, width, mouseX, mouseY);
                } else if (setting instanceof ColorSetting color) {
                    cursor = renderColor(ctx, screen, color, x, cursor, width, mouseX, mouseY);
                }
            }

            renderKeybind(ctx, screen, x, cursor, width, mouseX, mouseY);
        }

        private int renderBoolean(DrawContext ctx, ClickGuiScreen screen, BooleanSetting setting,
                                  int x, int y, int width, int mouseX, int mouseY) {
            int height = Theme.s(Theme.TOGGLE_HEIGHT);
            int left = x + Theme.s(Theme.INDENT + 5);
            boolean hovered = inside(mouseX, mouseY, x, y, width, height);
            if (hovered) {
                Theme.rect(ctx, x, y, width, height, Theme.ROW_HOVER);
            }
            int available = setting.isAvailable() ? 255 : 110;
            Theme.text(ctx, screen.textRenderer, Theme.trim(screen.textRenderer, setting.getName(), width - Theme.s(56)),
                    left, y + Theme.s(4), Theme.withAlpha(hovered ? Theme.TEXT : Theme.TEXT_DIM, available));

            int swWidth = Theme.s(20);
            int swHeight = Theme.s(9);
            int sx = x + width - swWidth - Theme.s(9);
            int sy = y + (height - swHeight) / 2;
            Theme.rect(ctx, sx, sy, swWidth, swHeight, setting.isOn() ? Theme.withAlpha(Theme.accent, 66) : Theme.SWITCH_OFF_BG);
            Theme.outline(ctx, sx, sy, swWidth, swHeight, setting.isOn() ? Theme.accent : Theme.SWITCH_OFF_BORDER);
            int knob = Theme.s(5);
            int kx = setting.isOn() ? sx + swWidth - knob - Theme.s(2) : sx + Theme.s(2);
            Theme.rect(ctx, kx, sy + Theme.s(2), knob, knob, setting.isOn() ? Theme.accent : Theme.SWITCH_OFF_KNOB);

            if (hovered && !setting.getDescription().isEmpty()) {
                screen.setTooltip(setting.getDescription(), mouseX, mouseY);
            }
            return y + height;
        }

        private int renderSlider(DrawContext ctx, ClickGuiScreen screen, NumberSetting setting,
                                 int x, int y, int width, int mouseX, int mouseY) {
            int height = Theme.s(Theme.SLIDER_HEIGHT);
            int left = x + Theme.s(Theme.INDENT + 5);
            boolean hovered = inside(mouseX, mouseY, x, y, width, height);
            if (hovered) {
                Theme.rect(ctx, x, y, width, height, Theme.ROW_HOVER);
            }
            int available = setting.isAvailable() ? 255 : 110;
            Theme.text(ctx, screen.textRenderer, Theme.trim(screen.textRenderer, setting.getName(), width - Theme.s(60)),
                    left, y + Theme.s(3), Theme.withAlpha(hovered ? Theme.TEXT : Theme.TEXT_DIM, available));
            String value = setting.format();
            int valueWidth = screen.textRenderer.getWidth(value);
            Theme.text(ctx, screen.textRenderer, value, x + width - valueWidth - Theme.s(9), y + Theme.s(3),
                    Theme.withAlpha(Theme.accent, available));

            int trackX = left;
            int trackWidth = width - Theme.s(Theme.INDENT) - Theme.s(14);
            int trackY = y + Theme.s(15);
            int trackHeight = Theme.s(3);
            Theme.rect(ctx, trackX, trackY, trackWidth, trackHeight, Theme.TRACK);
            int fillWidth = (int) (trackWidth * Math.max(0d, Math.min(1d, setting.ratio())));
            Theme.rect(ctx, trackX, trackY, fillWidth, trackHeight, Theme.withAlpha(Theme.accent, available));
            int knobSize = Theme.s(7);
            Theme.rect(ctx, trackX + fillWidth - knobSize / 2, trackY - knobSize / 2 + trackHeight / 2,
                    knobSize, knobSize, hovered || screen.dragSlider != null ? Theme.TEXT : Theme.accent);

            if (hovered && !setting.getDescription().isEmpty()) {
                screen.setTooltip(setting.getDescription() + "  [" + setting.getMin() + " .. " + setting.getMax() + "]", mouseX, mouseY);
            }
            return y + height;
        }

        private int renderEnum(DrawContext ctx, ClickGuiScreen screen, EnumSetting<?> setting,
                               int x, int y, int width, int mouseX, int mouseY) {
            int height = Theme.s(Theme.TOGGLE_HEIGHT);
            int left = x + Theme.s(Theme.INDENT + 5);
            boolean hovered = inside(mouseX, mouseY, x, y, width, height);
            if (hovered) {
                Theme.rect(ctx, x, y, width, height, Theme.ROW_HOVER);
            }
            Theme.text(ctx, screen.textRenderer, Theme.trim(screen.textRenderer, setting.getName(), width - Theme.s(96)),
                    left, y + Theme.s(4), hovered ? Theme.TEXT : Theme.TEXT_DIM);

            String label = setting.label();
            int labelWidth = screen.textRenderer.getWidth(label) + Theme.s(10);
            int lx = x + width - labelWidth - Theme.s(9);
            Theme.rect(ctx, lx, y + Theme.s(3), labelWidth, height - Theme.s(6), Theme.FIELD_BG);
            Theme.outline(ctx, lx, y + Theme.s(3), labelWidth, height - Theme.s(6),
                    hovered ? Theme.accent : Theme.BORDER);
            Theme.text(ctx, screen.textRenderer, label, lx + Theme.s(5), y + Theme.s(4), hovered ? Theme.accent : Theme.TEXT_DIM);
            return y + height;
        }

        private int renderColor(DrawContext ctx, ClickGuiScreen screen, ColorSetting setting,
                                int x, int y, int width, int mouseX, int mouseY) {
            int height = Theme.s(Theme.COLOR_HEIGHT);
            int left = x + Theme.s(Theme.INDENT + 5);
            boolean hovered = inside(mouseX, mouseY, x, y, width, height);
            if (hovered) {
                Theme.rect(ctx, x, y, width, height, Theme.ROW_HOVER);
            }
            Theme.text(ctx, screen.textRenderer, Theme.trim(screen.textRenderer, setting.getName(), width - Theme.s(78)),
                    left, y + Theme.s(4), hovered ? Theme.TEXT : Theme.TEXT_DIM);

            int swatchWidth = Theme.s(46);
            int swatchHeight = height - Theme.s(5);
            int sx = x + width - swatchWidth - Theme.s(9);
            int sy = y + Theme.s(2);
            // checkerboard so low alpha is visible
            for (int cx = 0; cx < swatchWidth; cx += Theme.s(4)) {
                for (int cy = 0; cy < swatchHeight; cy += Theme.s(4)) {
                    boolean dark = ((cx + cy) / Math.max(1, Theme.s(4))) % 2 == 0;
                    Theme.rect(ctx, sx + cx, sy + cy, Math.min(Theme.s(4), swatchWidth - cx),
                            Math.min(Theme.s(4), swatchHeight - cy), dark ? 0xFF2A3441 : 0xFF1B2430);
                }
            }
            Theme.rect(ctx, sx, sy, swatchWidth, swatchHeight, setting.getArgb());
            Theme.outline(ctx, sx, sy, swatchWidth, swatchHeight, hovered ? Theme.TEXT : Theme.BORDER);
            if (setting.isRainbow()) {
                Theme.text(ctx, screen.textRenderer, "R", sx + Theme.s(2), sy + Theme.s(1), 0xFF0A0E14);
            }

            boolean open = openColor == setting;
            Theme.text(ctx, screen.textRenderer, open ? "^" : "v", x + width - Theme.s(7), y + Theme.s(4), Theme.TEXT_FAINT);

            if (!open) {
                return y + height;
            }

            int editorY = y + height;
            int editorHeight = Theme.s(Theme.COLOR_EDITOR_HEIGHT);
            Theme.rect(ctx, x, editorY, width, editorHeight, 0xFF0A0E14);

            int sliderX = x + Theme.s(Theme.INDENT + 16);
            int sliderWidth = width - Theme.s(Theme.INDENT) - Theme.s(26);
            int rowHeight = Theme.s(11);
            int cursor = editorY + Theme.s(4);
            String[] names = {"R", "G", "B", "A"};
            int[] values = {setting.getRed(), setting.getGreen(), setting.getBlue(), setting.getAlpha()};
            int[] channelColors = {0xFFFF5C5C, 0xFF5CD65C, 0xFF5C9AFF, 0xFFC9D5E2};

            for (int i = 0; i < 4; i++) {
                Theme.text(ctx, screen.textRenderer, names[i], x + Theme.s(Theme.INDENT + 5), cursor + Theme.s(2), channelColors[i]);
                Theme.rect(ctx, sliderX, cursor + Theme.s(3), sliderWidth, Theme.s(3), Theme.TRACK);
                int fillWidth = (int) (sliderWidth * (values[i] / 255f));
                Theme.rect(ctx, sliderX, cursor + Theme.s(3), fillWidth, Theme.s(3), channelColors[i]);
                Theme.rect(ctx, sliderX + fillWidth - Theme.s(2), cursor + Theme.s(1), Theme.s(5), Theme.s(7), Theme.TEXT);
                String number = Integer.toString(values[i]);
                Theme.text(ctx, screen.textRenderer, number, x + width - screen.textRenderer.getWidth(number) - Theme.s(9),
                        cursor + Theme.s(2), Theme.TEXT_FAINT);
                cursor += rowHeight;
            }

            // hex field + rainbow toggle + presets
            int fieldY = cursor + Theme.s(1);
            int fieldWidth = width - Theme.s(Theme.INDENT) - Theme.s(46);
            boolean editing = screen.isHexTarget(setting);
            Theme.rect(ctx, x + Theme.s(Theme.INDENT + 5), fieldY, fieldWidth, Theme.s(11), Theme.FIELD_BG);
            Theme.outline(ctx, x + Theme.s(Theme.INDENT + 5), fieldY, fieldWidth, Theme.s(11),
                    editing ? Theme.accent : Theme.BORDER);
            String hex = editing ? "#" + screen.hexDraft() : ColorSetting.toHex(setting.get());
            Theme.text(ctx, screen.textRenderer, hex, x + Theme.s(Theme.INDENT + 9), fieldY + Theme.s(2),
                    editing ? Theme.accent : Theme.TEXT_DIM);

            String rainbow = setting.isRainbow() ? "RBW" : "rbw";
            int rbX = x + width - Theme.s(36);
            Theme.rect(ctx, rbX, fieldY, Theme.s(27), Theme.s(11),
                    setting.isRainbow() ? Theme.withAlpha(Theme.accent, 70) : Theme.FIELD_BG);
            Theme.outline(ctx, rbX, fieldY, Theme.s(27), Theme.s(11), setting.isRainbow() ? Theme.accent : Theme.BORDER);
            Theme.text(ctx, screen.textRenderer, rainbow, rbX + Theme.s(5), fieldY + Theme.s(2),
                    setting.isRainbow() ? Theme.accent : Theme.TEXT_FAINT);

            int presetY = fieldY + Theme.s(14);
            int presetSize = Theme.s(9);
            int presetX = x + Theme.s(Theme.INDENT + 5);
            for (int preset : PRESETS) {
                Theme.rect(ctx, presetX, presetY, presetSize, presetSize, preset);
                Theme.outline(ctx, presetX, presetY, presetSize, presetSize, 0x40FFFFFF);
                presetX += presetSize + Theme.s(3);
            }

            return editorY + editorHeight;
        }

        private void renderKeybind(DrawContext ctx, ClickGuiScreen screen, int x, int y, int width, int mouseX, int mouseY) {
            int height = Theme.s(Theme.TOGGLE_HEIGHT);
            boolean hovered = inside(mouseX, mouseY, x, y, width, height);
            if (hovered) {
                Theme.rect(ctx, x, y, width, height, Theme.ROW_HOVER);
            }
            int left = x + Theme.s(Theme.INDENT + 5);
            Theme.text(ctx, screen.textRenderer, "Keybind", left, y + Theme.s(4), hovered ? Theme.TEXT : Theme.TEXT_DIM);

            String label = module.isListening() ? "..." : module.getBindName();
            int labelWidth = Math.max(Theme.s(28), screen.textRenderer.getWidth(label) + Theme.s(10));
            int lx = x + width - labelWidth - Theme.s(9);
            int color = module.isListening() ? 0xFFFF5C7A : (hovered ? Theme.accent : Theme.TEXT_FAINT);
            Theme.rect(ctx, lx, y + Theme.s(3), labelWidth, height - Theme.s(6), Theme.FIELD_BG);
            Theme.outline(ctx, lx, y + Theme.s(3), labelWidth, height - Theme.s(6),
                    module.isListening() ? 0xFFFF5C7A : (hovered ? Theme.accent : Theme.BORDER));
            Theme.text(ctx, screen.textRenderer, label, lx + Theme.s(5), y + Theme.s(4), color);
            ctx.fill(x, y + height - 1, x + width, y + height, Theme.SETTINGS_LINE);
        }

        void mouseClicked(ClickGuiScreen screen, double mouseX, double mouseY, int button,
                          int x, int y, int width) {
            int headerHeight = Theme.s(Theme.MODULE_HEIGHT);
            if (inside(mouseX, mouseY, x, y, width, headerHeight)) {
                int swWidth = Theme.s(24);
                int sx = x + width - swWidth - Theme.s(22);
                int chevX = x + width - Theme.s(15);
                if (button == 0 && inside(mouseX, mouseY, sx, y, swWidth, headerHeight)) {
                    module.toggle();
                    ConfigManager.save();
                } else if (button == 0 && inside(mouseX, mouseY, chevX, y, Theme.s(15), headerHeight)) {
                    expanded = !expanded;
                } else if (button == 0) {
                    module.toggle();
                    ConfigManager.save();
                } else if (button == 1) {
                    expanded = !expanded;
                }
                return;
            }

            int cursor = y + headerHeight;
            if (!module.getDescription().isEmpty()) {
                cursor += Theme.s(12);
            }

            for (Setting<?> setting : module.getSettings()) {
                if (!setting.isVisible()) {
                    continue;
                }
                boolean colorOpen = setting instanceof ColorSetting color && openColor == color;
                int height;
                if (colorOpen) {
                    height = Theme.s(Theme.COLOR_HEIGHT + Theme.COLOR_EDITOR_HEIGHT);
                } else if (setting instanceof NumberSetting) {
                    height = Theme.s(Theme.SLIDER_HEIGHT);
                } else if (setting instanceof ColorSetting) {
                    height = Theme.s(Theme.COLOR_HEIGHT);
                } else {
                    height = Theme.s(Theme.TOGGLE_HEIGHT);
                }

                if (inside(mouseX, mouseY, x, cursor, width, height)) {
                    handleSetting(screen, setting, mouseX, mouseY, button, x, cursor, width, height);
                    return;
                }
                cursor += height;
            }

            // keybind row
            if (inside(mouseX, mouseY, x, cursor, width, Theme.s(Theme.TOGGLE_HEIGHT))) {
                if (button == 0) {
                    screen.setBinding(module);
                } else if (button == 1) {
                    module.setBind(-1);
                    ConfigManager.save();
                }
            }
        }

        private void handleSetting(ClickGuiScreen screen, Setting<?> setting, double mouseX, double mouseY,
                                   int button, int x, int y, int width, int height) {
            if (button == 1) {
                setting.reset();
                if (setting instanceof ColorSetting color) {
                    color.setRainbow(false);
                }
                ConfigManager.save();
                return;
            }

            if (setting instanceof BooleanSetting bool) {
                bool.toggle();
                ConfigManager.save();
                return;
            }

            if (setting instanceof EnumSetting<?> enumeration) {
                enumeration.cycle(screen.hasShiftDown() ? -1 : 1);
                ConfigManager.save();
                return;
            }

            if (setting instanceof NumberSetting number) {
                SliderWidget widget = new SliderWidget(number, x + Theme.s(Theme.INDENT + 5),
                        y + Theme.s(15), width - Theme.s(Theme.INDENT) - Theme.s(14));
                widget.drag(mouseX);
                screen.setDragSlider(widget);
                ConfigManager.save();
                return;
            }

            if (setting instanceof ColorSetting color) {
                int editorY = y + Theme.s(Theme.COLOR_HEIGHT);
                if (mouseY < editorY) {
                    // clicked the swatch row: expand / collapse, or grab the hex field
                    openColor = openColor == color ? null : color;
                    return;
                }
                editColor(screen, color, mouseX, mouseY, x, editorY, width);
            }
        }

        private void editColor(ClickGuiScreen screen, ColorSetting color, double mouseX, double mouseY,
                               int x, int editorY, int width) {
            int sliderX = x + Theme.s(Theme.INDENT + 16);
            int sliderWidth = width - Theme.s(Theme.INDENT) - Theme.s(26);
            int rowHeight = Theme.s(11);
            int cursor = editorY + Theme.s(4);

            for (int channel = 0; channel < 4; channel++) {
                if (inside(mouseX, mouseY, sliderX - Theme.s(11), cursor, sliderWidth + Theme.s(20), rowHeight)) {
                    int value = (int) Math.round(((mouseX - sliderX) / Math.max(1, sliderWidth)) * 255d);
                    value = Math.max(0, Math.min(255, value));
                    switch (channel) {
                        case 0 -> color.setRed(value);
                        case 1 -> color.setGreen(value);
                        case 2 -> color.setBlue(value);
                        default -> color.setAlpha(value);
                    }
                    ConfigManager.save();
                    return;
                }
                cursor += rowHeight;
            }

            int fieldY = cursor + Theme.s(1);
            int fieldWidth = width - Theme.s(Theme.INDENT) - Theme.s(46);
            if (inside(mouseX, mouseY, x + Theme.s(Theme.INDENT + 5), fieldY, fieldWidth, Theme.s(11))) {
                screen.setHexTarget(color);
                return;
            }
            int rbX = x + width - Theme.s(36);
            if (inside(mouseX, mouseY, rbX, fieldY, Theme.s(27), Theme.s(11))) {
                color.setRainbow(!color.isRainbow());
                ConfigManager.save();
                return;
            }

            int presetY = fieldY + Theme.s(14);
            int presetSize = Theme.s(9);
            int presetX = x + Theme.s(Theme.INDENT + 5);
            for (int preset : PRESETS) {
                if (inside(mouseX, mouseY, presetX, presetY, presetSize, presetSize)) {
                    color.set((preset & 0x00FFFFFF) | (color.getAlpha() << 24));
                    color.setRainbow(false);
                    ConfigManager.save();
                    return;
                }
                presetX += presetSize + Theme.s(3);
            }
        }
    }

    // ---------------------------------------------------------------- slider helper

    /** Translates a mouse X into a clamped, stepped value for a {@link NumberSetting}. */
    static final class SliderWidget {

        private final NumberSetting setting;
        private final int trackX;
        private final int trackWidth;

        SliderWidget(NumberSetting setting, int trackX, int trackY, int trackWidth) {
            this.setting = setting;
            this.trackX = trackX;
            this.trackWidth = Math.max(1, trackWidth);
        }

        void drag(double mouseX) {
            double ratio = (mouseX - trackX) / trackWidth;
            double value = setting.getMin() + (setting.getMax() - setting.getMin()) * ratio;
            setting.set(value);
        }
    }
}