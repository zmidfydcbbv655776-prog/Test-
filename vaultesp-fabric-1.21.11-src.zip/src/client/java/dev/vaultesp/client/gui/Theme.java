package dev.vaultesp.client.gui;

import dev.vaultesp.client.module.ModuleManager;
import dev.vaultesp.client.modules.ClickGuiModule;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

/**
 * Colours, spacing and scale for the ClickGUI. {@link #sync()} is called once per GUI frame, so
 * dragging the accent colour slider repaints the panel you are dragging it in.
 */
public final class Theme {

    // live values, driven by ClickGuiModule
    public static int accent = 0xFFFFB020;
    public static float scale = 1f;

    // fixed chrome
    public static final int PANEL_BG = 0xF20C1118;
    public static final int HEADER_BG = 0xFF1B2431;
    public static final int HEADER_LINE = 0xFF26313F;
    public static final int ROW_HOVER = 0xFF18212C;
    public static final int ROW_OPEN = 0xFF1A2430;
    public static final int SETTINGS_BG = 0xFF0E141C;
    public static final int SETTINGS_LINE = 0xFF151D27;
    public static final int BORDER = 0xFF26313F;
    public static final int TEXT = 0xFFE8EEF6;
    public static final int TEXT_DIM = 0xFF8A98AA;
    public static final int TEXT_FAINT = 0xFF5D6B7C;
    public static final int TRACK = 0xFF232E3C;
    public static final int SWITCH_OFF_BG = 0xFF131A23;
    public static final int SWITCH_OFF_BORDER = 0xFF33404F;
    public static final int SWITCH_OFF_KNOB = 0xFF4A5A6C;
    public static final int FIELD_BG = 0xFF0A0E14;

    // geometry (before scale)
    public static final int PANEL_WIDTH = 152;
    public static final int HEADER_HEIGHT = 21;
    public static final int MODULE_HEIGHT = 19;
    public static final int TOGGLE_HEIGHT = 15;
    public static final int SLIDER_HEIGHT = 25;
    public static final int COLOR_HEIGHT = 17;
    public static final int COLOR_EDITOR_HEIGHT = 84;
    public static final int INDENT = 9;
    public static final int BODY_MAX = 268;

    private Theme() {
    }

    public static void sync() {
        ClickGuiModule gui = ModuleManager.get().get(ClickGuiModule.class);
        accent = gui.accentColor.getArgb();
        scale = Math.max(0.5f, Math.min(2.5f, gui.scale.getFloat()));
    }

    /** Scales a layout constant by the current GUI scale. */
    public static int s(int value) {
        return Math.round(value * scale);
    }

    public static int s(float value) {
        return Math.round(value * scale);
    }

    public static int withAlpha(int argb, int alpha) {
        return (Math.max(0, Math.min(255, alpha)) << 24) | (argb & 0x00FFFFFF);
    }

    /** Linear blend between two ARGB colours, t in 0..1. */
    public static int mix(int from, int to, float t) {
        float k = t < 0f ? 0f : Math.min(t, 1f);
        int a = Math.round(((from >>> 24) + ((to >>> 24) - (from >>> 24)) * k));
        int r = Math.round((((from >> 16) & 0xFF) + (((to >> 16) & 0xFF) - ((from >> 16) & 0xFF)) * k));
        int g = Math.round((((from >> 8) & 0xFF) + (((to >> 8) & 0xFF) - ((from >> 8) & 0xFF)) * k));
        int b = Math.round(((from & 0xFF) + ((to & 0xFF) - (from & 0xFF)) * k));
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    public static void rect(DrawContext ctx, int x, int y, int width, int height, int color) {
        ctx.fill(x, y, x + width, y + height, color);
    }

    public static void outline(DrawContext ctx, int x, int y, int width, int height, int color) {
        ctx.fill(x, y, x + width, y + 1, color);
        ctx.fill(x, y + height - 1, x + width, y + height, color);
        ctx.fill(x, y, x + 1, y + height, color);
        ctx.fill(x + width - 1, y, x + width, y + height, color);
    }

    public static int text(DrawContext ctx, TextRenderer fonts, String value, int x, int y, int color) {
        ctx.drawText(fonts, value, x, y, color, false);
        return fonts.getWidth(value);
    }

    public static String trim(TextRenderer fonts, String value, int maxWidth) {
        if (fonts.getWidth(value) <= maxWidth) {
            return value;
        }
        String text = value;
        while (text.length() > 1 && fonts.getWidth(text + "..") > maxWidth) {
            text = text.substring(0, text.length() - 1);
        }
        return text + "..";
    }
}