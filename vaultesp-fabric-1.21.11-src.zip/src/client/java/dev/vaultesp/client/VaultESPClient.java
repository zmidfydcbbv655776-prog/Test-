package dev.vaultesp.client;

import dev.vaultesp.VaultESP;
import dev.vaultesp.client.command.VaultCommand;
import dev.vaultesp.client.config.ConfigManager;
import dev.vaultesp.client.gui.ClickGuiScreen;
import dev.vaultesp.client.module.Module;
import dev.vaultesp.client.module.ModuleManager;
import dev.vaultesp.client.render.ESPPipeline;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.HashMap;
import java.util.Map;

/**
 * Client entrypoint: loads the config, wires the render/scan pipeline, registers the
 * GUI keybind and the {@code /vaultesp} command, and polls per-module keybinds.
 */
public class VaultESPClient implements ClientModInitializer {

    /** Opens / closes the ClickGUI. Rebound freely from the vanilla controls screen. */
    public static KeyBinding guiKey;

    /** Edge detector so holding a module keybind toggles it exactly once. */
    private static final Map<Integer, Boolean> KEY_STATE = new HashMap<>();

    @Override
    public void onInitializeClient() {
        guiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.vaultesp.opengui",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "key.categories.vaultesp"));

        ConfigManager.load();
        ESPPipeline.get().register();
        VaultCommand.register();

        ClientTickEvents.END_CLIENT_TICK.register(VaultESPClient::onTick);

        ModuleManager modules = ModuleManager.get();
        VaultESP.LOGGER.info("[{}] client ready - {} modules / {} settings / scan+render pipeline registered.",
                VaultESP.MOD_NAME, modules.all().size(), modules.settingCount());
    }

    private static void onTick(MinecraftClient mc) {
        while (guiKey.wasPressed()) {
            if (mc.currentScreen instanceof ClickGuiScreen) {
                mc.setScreen(null);
            } else if (mc.currentScreen == null && mc.player != null) {
                mc.setScreen(ClickGuiScreen.INSTANCE);
            }
        }

        // Module hotkeys only fire while no screen is stealing input.
        if (mc.currentScreen != null || mc.player == null || mc.getWindow() == null) {
            KEY_STATE.clear();
            return;
        }

        long window = mc.getWindow().getHandle();

        for (Module module : ModuleManager.get().all()) {
            int code = module.getBind();
            if (code < 0) {
                continue;
            }
            boolean down = InputUtil.isKeyPressed(window, code);
            boolean was = KEY_STATE.getOrDefault(code, Boolean.FALSE);

            if (down && !was) {
                module.toggle();
                mc.player.sendMessage(Text.translatable(
                        module.isEnabled() ? "text.vaultesp.enabled" : "text.vaultesp.disabled",
                        module.getName()), true);
            }
            KEY_STATE.put(code, down);
        }
    }
}