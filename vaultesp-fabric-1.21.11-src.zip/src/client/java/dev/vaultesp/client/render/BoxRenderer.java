package dev.vaultesp.client.render;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;

/**
 * Immediate-mode box renderer shared by every ESP module.
 *
 * <p><b>Why it is written this way</b></p>
 * <ul>
 *   <li><b>Camera-relative vertices.</b> Positions are emitted relative to the camera, so no matrix
 *       multiply happens per vertex and the model-view matrix the world renderer already installed is
 *       reused untouched. This also removes float precision drift far from origin.</li>
 *   <li><b>Outlines are ribbons, not GL lines.</b> {@code glLineWidth} is silently clamped to 1.0 on
 *       every modern core-profile driver, so "outline thickness" would be a dead setting. Instead each
 *       of the 12 edges becomes a camera-facing quad sized from the live projection matrix, giving a
 *       thickness that is genuinely constant in screen pixels at any distance.</li>
 *   <li><b>Front faces only.</b> Depth testing is disabled for the ESP pass, so drawing back faces
 *       would double the overdraw and wash the colour out. One dot product per face skips them.</li>
 *   <li><b>Batched.</b> One buffer per layer, so a frame costs exactly three draw calls regardless of
 *       how many blocks were found.</li>
 * </ul>
 */
public final class BoxRenderer {

    /** tan(fov / 2), derived from the active projection matrix (m11 == 1 / tan(fov / 2)). */
    private static float tanHalfFov = 0.7002f;
    private static double screenHeight = 1080d;

    private BoxRenderer() {
    }

    /**
     * Call once per frame before emitting geometry.
     *
     * @param projectionM11     {@code WorldRenderContext#projectionMatrix().m11}
     * @param scaledScreenHeight scaled window height in pixels
     */
    public static void configure(float projectionM11, double scaledScreenHeight) {
        tanHalfFov = projectionM11 > 1e-4f ? 1f / projectionM11 : 0.7002f;
        screenHeight = scaledScreenHeight > 1d ? scaledScreenHeight : 1080d;
    }

    /** World-space size of one screen pixel at {@code distance} blocks from the camera. */
    public static float pixelToWorld(double distance) {
        return (float) (2d * tanHalfFov * Math.max(0.05d, distance) / screenHeight);
    }

    // ---------------------------------------------------------------- GL state

    public static void setupGl() {
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableDepthTest();
        RenderSystem.disableCull();
        RenderSystem.depthMask(false);
    }

    public static void restoreGl() {
        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
    }

    public static BufferBuilder beginQuads() {
        return Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
    }

    /** Ends the buffer and uploads it. Safe to call on an empty buffer. */
    public static void flush(BufferBuilder buffer) {
        BufferBuilder.BuiltBuffer built = buffer.endNullable();
        if (built != null) {
            BufferRenderer.drawWithGlobalProgram(built);
        }
    }

    // ---------------------------------------------------------------- primitives

    private static void vertex(BufferBuilder buffer, double x, double y, double z, int argb) {
        buffer.vertex((float) x, (float) y, (float) z).color(
                ((argb >> 16) & 0xFF) / 255f,
                ((argb >> 8) & 0xFF) / 255f,
                (argb & 0xFF) / 255f,
                ((argb >>> 24) & 0xFF) / 255f);
    }

    private static void quad(BufferBuilder buffer,
                             double ax, double ay, double az, int ca,
                             double bx, double by, double bz, int cb,
                             double cx, double cy, double cz, int cc,
                             double dx, double dy, double dz, int cd) {
        vertex(buffer, ax, ay, az, ca);
        vertex(buffer, bx, by, bz, cb);
        vertex(buffer, cx, cy, cz, cc);
        vertex(buffer, dx, dy, dz, cd);
    }

    private static void quad(BufferBuilder buffer,
                             double ax, double ay, double az,
                             double bx, double by, double bz,
                             double cx, double cy, double cz,
                             double dx, double dy, double dz, int color) {
        quad(buffer, ax, ay, az, color, bx, by, bz, color, cx, cy, cz, color, dx, dy, dz, color);
    }

    // ---------------------------------------------------------------- fill

    /**
     * Translucent box faces. Coordinates are camera relative, so the camera sits at the origin and
     * a face is front-facing when the negated coordinate of its plane is positive.
     */
    public static void fill(BufferBuilder buffer, double x0, double y0, double z0,
                            double x1, double y1, double z1, int argb) {
        if (x1 < 0d) { // +X face
            quad(buffer, x1, y0, z0, x1, y0, z1, x1, y1, z1, x1, y1, z0, argb);
        }
        if (x0 > 0d) { // -X face
            quad(buffer, x0, y0, z1, x0, y0, z0, x0, y1, z0, x0, y1, z1, argb);
        }
        if (y1 < 0d) { // +Y face (top)
            quad(buffer, x0, y1, z0, x1, y1, z0, x1, y1, z1, x0, y1, z1, argb);
        }
        if (y0 > 0d) { // -Y face (bottom)
            quad(buffer, x0, y0, z1, x1, y0, z1, x1, y0, z0, x0, y0, z0, argb);
        }
        if (z1 < 0d) { // +Z face
            quad(buffer, x1, y0, z1, x0, y0, z1, x0, y1, z1, x1, y1, z1, argb);
        }
        if (z0 > 0d) { // -Z face
            quad(buffer, x0, y0, z0, x1, y0, z0, x1, y1, z0, x0, y1, z0, argb);
        }
    }

    // ---------------------------------------------------------------- outline

    /**
     * Twelve camera-facing edge ribbons plus eight corner caps, so the outline stays continuous
     * at every viewing angle instead of opening up into a star of disjoint lines.
     *
     * @param thicknessPx outline thickness in screen pixels
     */
    public static void outline(BufferBuilder buffer, double x0, double y0, double z0,
                               double x1, double y1, double z1, int argb, float thicknessPx) {
        if (thicknessPx <= 0.01f) {
            return;
        }
        // bottom ring
        edge(buffer, x0, y0, z0, x1, y0, z0, argb, thicknessPx);
        edge(buffer, x1, y0, z0, x1, y0, z1, argb, thicknessPx);
        edge(buffer, x1, y0, z1, x0, y0, z1, argb, thicknessPx);
        edge(buffer, x0, y0, z1, x0, y0, z0, argb, thicknessPx);
        // top ring
        edge(buffer, x0, y1, z0, x1, y1, z0, argb, thicknessPx);
        edge(buffer, x1, y1, z0, x1, y1, z1, argb, thicknessPx);
        edge(buffer, x1, y1, z1, x0, y1, z1, argb, thicknessPx);
        edge(buffer, x0, y1, z1, x0, y1, z0, argb, thicknessPx);
        // verticals
        edge(buffer, x0, y0, z0, x0, y1, z0, argb, thicknessPx);
        edge(buffer, x1, y0, z0, x1, y1, z0, argb, thicknessPx);
        edge(buffer, x1, y0, z1, x1, y1, z1, argb, thicknessPx);
        edge(buffer, x0, y0, z1, x0, y1, z1, argb, thicknessPx);
        // corner caps
        cap(buffer, x0, y0, z0, argb, thicknessPx);
        cap(buffer, x1, y0, z0, argb, thicknessPx);
        cap(buffer, x0, y0, z1, argb, thicknessPx);
        cap(buffer, x1, y0, z1, argb, thicknessPx);
        cap(buffer, x0, y1, z0, argb, thicknessPx);
        cap(buffer, x1, y1, z0, argb, thicknessPx);
        cap(buffer, x0, y1, z1, argb, thicknessPx);
        cap(buffer, x1, y1, z1, argb, thicknessPx);
    }

    /** One edge, expanded into a quad perpendicular to the view direction through its midpoint. */
    private static void edge(BufferBuilder buffer, double ax, double ay, double az,
                             double bx, double by, double bz, int argb, float thicknessPx) {
        double dx = bx - ax;
        double dy = by - ay;
        double dz = bz - az;
        double edgeLength = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (edgeLength < 1e-9d) {
            return;
        }
        dx /= edgeLength;
        dy /= edgeLength;
        dz /= edgeLength;

        double mx = (ax + bx) * 0.5d;
        double my = (ay + by) * 0.5d;
        double mz = (az + bz) * 0.5d;

        // view vector: midpoint -> camera, and the camera is the origin in this space
        double viewLength = Math.sqrt(mx * mx + my * my + mz * mz);
        if (viewLength < 1e-6d) {
            return;
        }
        double vx = -mx / viewLength;
        double vy = -my / viewLength;
        double vz = -mz / viewLength;

        double half = pixelToWorld(viewLength) * thicknessPx * 0.5d;
        if (half <= 0d) {
            return;
        }

        // side = normalise(cross(edge, view)) * half
        double sx = dy * vz - dz * vy;
        double sy = dz * vx - dx * vz;
        double sz = dx * vy - dy * vx;
        double sideLength = Math.sqrt(sx * sx + sy * sy + sz * sz);
        if (sideLength < 1e-9d) {
            return; // edge points straight at the camera: the corner caps cover it
        }
        sx = sx / sideLength * half;
        sy = sy / sideLength * half;
        sz = sz / sideLength * half;

        quad(buffer,
                ax - sx, ay - sy, az - sz,
                bx - sx, by - sy, bz - sz,
                bx + sx, by + sy, bz + sz,
                ax + sx, ay + sy, az + sz, argb);
    }

    /** A small camera-facing square over a corner so ribbons meet cleanly. */
    private static void cap(BufferBuilder buffer, double cx, double cy, double cz, int argb, float thicknessPx) {
        double length = Math.sqrt(cx * cx + cy * cy + cz * cz);
        if (length < 1e-6d) {
            return;
        }
        double vx = -cx / length;
        double vy = -cy / length;
        double vz = -cz / length;
        double half = pixelToWorld(length) * thicknessPx * 0.5d;

        // basis perpendicular to the view: cross(view, worldUp), falling back to worldRight
        double ax = vy * 0d - vz * 1d;
        double ay = vz * 0d - vx * 0d;
        double az = vx * 1d - vy * 0d;
        double aLength = Math.sqrt(ax * ax + ay * ay + az * az);
        if (aLength < 1e-6d) {
            ax = 0d;
            ay = 0d;
            az = 1d;
            aLength = 1d;
        }
        ax /= aLength;
        ay /= aLength;
        az /= aLength;

        double bx = vy * az - vz * ay;
        double by = vz * ax - vx * az;
        double bz = vx * ay - vy * ax;

        quad(buffer,
                cx + (ax + bx) * half, cy + (ay + by) * half, cz + (az + bz) * half,
                cx + (ax - bx) * half, cy + (ay - by) * half, cz + (az - bz) * half,
                cx - (ax + bx) * half, cy - (ay + by) * half, cz - (az + bz) * half,
                cx - (ax - bx) * half, cy - (ay - by) * half, cz - (az - bz) * half, argb);
    }

    // ---------------------------------------------------------------- tracers

    /**
     * An alpha-graded ribbon from just in front of the camera to the target, so the eye is led to
     * the block without a solid beam plastered across the screen.
     *
     * @param tx camera-relative target x
     * @param ty camera-relative target y
     * @param tz camera-relative target z
     */
    public static void tracer(BufferBuilder buffer, double tx, double ty, double tz,
                              int argb, float thicknessPx, float farAlpha, float nearAlpha) {
        double distance = Math.sqrt(tx * tx + ty * ty + tz * tz);
        if (distance < 0.6d) {
            return;
        }
        double dx = tx / distance;
        double dy = ty / distance;
        double dz = tz / distance;

        // start slightly in front of the camera so the ribbon does not cover the crosshair
        double start = 0.45d;
        double sx = dx * start;
        double sy = dy * start;
        double sz = dz * start;

        double half = pixelToWorld(distance) * thicknessPx * 0.5d;
        if (half <= 0d) {
            return;
        }

        double ax = dy * 0d - dz * 1d;
        double ay = dz * 0d - dx * 0d;
        double az = dx * 1d - dy * 0d;
        double aLength = Math.sqrt(ax * ax + ay * ay + az * az);
        if (aLength < 1e-6d) {
            ax = 1d;
            ay = 0d;
            az = 0d;
            aLength = 1d;
        }
        ax = ax / aLength * half;
        ay = ay / aLength * half;
        az = az / aLength * half;

        int near = scaleAlpha(argb, nearAlpha);
        int far = scaleAlpha(argb, farAlpha);

        quad(buffer,
                sx - ax, sy - ay, sz - az, near,
                tx - ax, ty - ay, tz - az, far,
                tx + ax, ty + ay, tz + az, far,
                sx + ax, sy + ay, sz + az, near);
    }

    /** Multiplies an ARGB colour's alpha channel by a 0..1 factor. */
    public static int scaleAlpha(int argb, float factor) {
        int alpha = (int) (((argb >>> 24) & 0xFF) * Math.max(0f, Math.min(1f, factor)));
        return (alpha << 24) | (argb & 0x00FFFFFF);
    }
}