package dev.vaultesp.client.render;

import it.unimi.dsi.fastutil.bytes.ByteArrayList;
import it.unimi.dsi.fastutil.longs.Long2ByteMap;
import it.unimi.dsi.fastutil.longs.Long2ByteOpenHashMap;
import it.unimi.dsi.fastutil.longs.LongArrayList;
import net.minecraft.block.BarrelBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.ChestBlock;
import net.minecraft.block.EnderChestBlock;
import net.minecraft.block.HopperBlock;
import net.minecraft.block.ShulkerBoxBlock;
import net.minecraft.block.SpawnerBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.ChunkStatus;
import net.minecraft.world.chunk.Palette;
import net.minecraft.world.chunk.WorldChunk;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 * Finds highlighted blocks without ever costing a frame.
 *
 * <p><b>Strategy.</b> Chunks inside the scan radius are queued as a nearest-first ring spiral and
 * drained at a fixed budget per tick. For each chunk the scanner walks its {@link ChunkSection}s and
 * rejects them twice before reading a single block:</p>
 * <ol>
 *   <li>{@code hasOnlyAir()} - skips every sky section above the terrain;</li>
 *   <li>palette rejection - a section's block-state palette is asked whether it contains <em>any</em>
 *       target block. A 4096-block section of pure netherrack, stone or deepslate is discarded for the
 *       price of two or three palette lookups.</li>
 * </ol>
 *
 * <p>Results accumulate into a {@link Long2ByteOpenHashMap} across the whole pass and are flattened
 * into two parallel primitive arrays on commit, so the renderer always sees a complete, consistent
 * snapshot and never a half-built one. Nothing here runs off the client thread and nothing allocates
 * per block.</p>
 */
public final class BlockScanner {

    // Target bit flags. Stored in a byte, so eight families is the ceiling.
    public static final byte TYPE_CHEST = 1;
    public static final byte TYPE_HOPPER = 2;
    public static final byte TYPE_SHULKER = 4;
    public static final byte TYPE_BARREL = 8;
    public static final byte TYPE_ENDER = 16;
    public static final byte TYPE_SPAWNER = 32;
    public static final byte TYPE_DEBRIS = 64;
    public static final byte TYPE_NONE = 0;

    /** Safety valve: a hostile map full of shulkers must not be able to blow up the frame. */
    public static final int HARD_TARGET_CAP = 8192;

    private final Long2ByteOpenHashMap pass = new Long2ByteOpenHashMap();
    private final LongArrayList renderPos = new LongArrayList();
    private final ByteArrayList renderType = new ByteArrayList();
    private final int[] counts = new int[7];

    private final Deque<Long> queue = new ArrayDeque<>();

    private int tickCounter;
    private int signature = Integer.MIN_VALUE;
    private int totalFound;

    // profiling counters, surfaced in the HUD and by /vaultesp stats
    private long sectionsRejected;
    private long sectionsScanned;
    private long blocksRead;
    private int lastPassTicks;
    private int passTicks;

    /** Classifies a block state. {@code TrappedChestBlock} extends {@code ChestBlock}, and every one
     *  of the seventeen shulker boxes is a {@code ShulkerBoxBlock}, so no per-variant lists are needed. */
    public static byte typeOf(BlockState state) {
        Block block = state.getBlock();
        if (block instanceof ChestBlock) {
            return TYPE_CHEST;
        }
        if (block instanceof HopperBlock) {
            return TYPE_HOPPER;
        }
        if (block instanceof ShulkerBoxBlock) {
            return TYPE_SHULKER;
        }
        if (block instanceof BarrelBlock) {
            return TYPE_BARREL;
        }
        if (block instanceof EnderChestBlock) {
            return TYPE_ENDER;
        }
        if (block instanceof SpawnerBlock) {
            return TYPE_SPAWNER;
        }
        if (block == Blocks.ANCIENT_DEBRIS) {
            return TYPE_DEBRIS;
        }
        return TYPE_NONE;
    }

    // ---------------------------------------------------------------- accessors for the renderer

    public int size() {
        return renderPos.size();
    }

    public long pos(int index) {
        return renderPos.getLong(index);
    }

    public byte type(int index) {
        return renderType.getByte(index);
    }

    /** How many committed targets carry the given flag. Index is log2(flag). */
    public int count(byte typeFlag) {
        int index = Integer.numberOfTrailingZeros(typeFlag);
        return index >= 0 && index < counts.length ? counts[index] : 0;
    }

    public int totalFound() {
        return totalFound;
    }

    public long sectionsRejected() {
        return sectionsRejected;
    }

    public long sectionsScanned() {
        return sectionsScanned;
    }

    public long blocksRead() {
        return blocksRead;
    }

    public int lastPassTicks() {
        return lastPassTicks;
    }

    /** How far through the current pass we are, 0..1 - used by the HUD progress bar. */
    public float passProgress() {
        return queue.isEmpty() ? 1f : 1f - Math.min(1f, queue.size() / 512f);
    }

    /**
     * Forces the next tick to rebuild the queue and restart the pass. Called by modules whose
     * enabled state changes the Y band the union of active modules cares about.
     */
    public void invalidateYRange() {
        signature = Integer.MIN_VALUE;
        tickCounter = 0;
    }

    public void clear() {
        queue.clear();
        pass.clear();
        renderPos.clear();
        renderType.clear();
        java.util.Arrays.fill(counts, 0);
        totalFound = 0;
        tickCounter = 0;
        passTicks = 0;
        signature = Integer.MIN_VALUE;
    }

    // ---------------------------------------------------------------- scanning

    /**
     * Advances the scan by at most {@code chunksPerTick} chunks and commits a finished pass.
     *
     * @param radiusBlocks      half-width of the square scan area, in blocks
     * @param chunksPerTick     frame budget, in chunks
     * @param rescanInterval    ticks between full re-scans
     * @param minY              lowest Y the union of active modules cares about
     * @param maxY              highest Y the union of active modules cares about
     */
    public void tick(MinecraftClient mc, int radiusBlocks, int chunksPerTick, int rescanInterval, int minY, int maxY) {
        ClientWorld world = mc.world;
        if (world == null || mc.player == null) {
            clear();
            return;
        }

        int radius = Math.max(16, Math.min(256, radiusBlocks));
        int budget = Math.max(1, Math.min(32, chunksPerTick));
        int interval = Math.max(2, Math.min(600, rescanInterval));

        // Any change to the scan volume invalidates the queue and the committed snapshot.
        int newSignature = radius * 31 + minY * 7919 + maxY * 104729;
        if (newSignature != signature) {
            signature = newSignature;
            clear();
            rebuildQueue(world, mc, radius);
        }

        tickCounter++;
        if (tickCounter >= interval) {
            tickCounter = 0;
            rebuildQueue(world, mc, radius);
        }

        int processed = 0;
        while (processed < budget && !queue.isEmpty()) {
            long packed = queue.pollFirst();
            WorldChunk chunk = loadedChunk(world, packed);
            if (chunk != null) {
                scanChunk(chunk, minY, maxY);
            }
            processed++;
        }

        passTicks++;
        if (queue.isEmpty()) {
            commitPass();
        }
    }

    /** Nearest-first ring spiral so the blocks around the player show up within the first few ticks. */
    private void rebuildQueue(ClientWorld world, MinecraftClient mc, int radiusBlocks) {
        queue.clear();
        BlockPos origin = mc.player.getBlockPos();
        int centreX = origin.getX() >> 4;
        int centreZ = origin.getZ() >> 4;
        int chunkRadius = (radiusBlocks >> 4) + 1;

        for (int ring = 0; ring <= chunkRadius; ring++) {
            for (int dx = -ring; dx <= ring; dx++) {
                for (int dz = -ring; dz <= ring; dz++) {
                    if (Math.max(Math.abs(dx), Math.abs(dz)) != ring) {
                        continue; // only the outer square of this ring
                    }
                    queue.addLast(ChunkPos.toLong(centreX + dx, centreZ + dz));
                }
            }
        }
        passTicks = 0;
    }

    private static WorldChunk loadedChunk(ClientWorld world, long packedChunkPos) {
        int chunkX = ChunkPos.getPackedX(packedChunkPos);
        int chunkZ = ChunkPos.getPackedZ(packedChunkPos);
        Chunk chunk = world.getChunk(chunkX, chunkZ, ChunkStatus.FULL, false);
        return chunk instanceof WorldChunk worldChunk ? worldChunk : null;
    }

    private void scanChunk(WorldChunk chunk, int minY, int maxY) {
        int sectionCount = chunk.getSectionCount();
        int baseX = chunk.getPos().x << 4;
        int baseZ = chunk.getPos().z << 4;

        for (int index = 0; index < sectionCount; index++) {
            ChunkSection section = chunk.getSection(index);
            if (section == null || section.hasOnlyAir()) {
                sectionsRejected++;
                continue;
            }
            int baseY = section.getMinY();
            if (baseY + 15 < minY || baseY > maxY) {
                sectionsRejected++;
                continue;
            }
            if (!paletteMayContainTargets(section)) {
                sectionsRejected++;
                continue;
            }

            sectionsScanned++;
            for (int y = 0; y < 16; y++) {
                int worldY = baseY + y;
                if (worldY < minY || worldY > maxY) {
                    continue;
                }
                for (int z = 0; z < 16; z++) {
                    for (int x = 0; x < 16; x++) {
                        blocksRead++;
                        byte type = typeOf(section.getBlockState(x, y, z));
                        if (type != TYPE_NONE) {
                            pass.put(BlockPos.asLong(baseX + x, worldY, baseZ + z), type);
                        }
                    }
                }
            }
        }
    }

    /**
     * Cheap rejection: does this section's block-state palette mention any target block at all?
     * Falls open (returns true) if the palette is unavailable, so an optimisation can never
     * silently switch the ESP off.
     */
    private static boolean paletteMayContainTargets(ChunkSection section) {
        try {
            Palette<BlockState> palette = section.getBlockStateContainer().getPalette();
            int size = palette.getSize();
            for (int i = 0; i < size; i++) {
                BlockState state = palette.getByIndex(i);
                if (state != null && typeOf(state) != TYPE_NONE) {
                    return true;
                }
            }
            return false;
        } catch (RuntimeException | LinkageError error) {
            return true;
        }
    }

    /** Flattens the finished pass into the arrays the renderer reads. */
    private void commitPass() {
        renderPos.clear();
        renderType.clear();
        java.util.Arrays.fill(counts, 0);

        int limit = HARD_TARGET_CAP;
        for (Long2ByteMap.Entry entry : pass.long2ByteEntrySet()) {
            if (limit-- <= 0) {
                break;
            }
            long packed = entry.getLongKey();
            byte type = entry.getByteValue();
            renderPos.add(packed);
            renderType.add(type);
            int slot = Integer.numberOfTrailingZeros(type);
            if (slot >= 0 && slot < counts.length) {
                counts[slot]++;
            }
        }
        totalFound = renderPos.size();
        pass.clear();
        lastPassTicks = passTicks;
        passTicks = 0;
    }
}