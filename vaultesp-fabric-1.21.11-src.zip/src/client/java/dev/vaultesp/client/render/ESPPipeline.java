package dev.vaultesp.client.render;

import dev.vaultesp.client.module.Module;
import dev.vaultesp.client.module.ModuleManager;
import dev.vaultesp.client.modules.AncientDebrisESPModule;
import dev.vaultesp.client.modules.ClickGuiModule;
import dev.vaultesp.client.modules.HudModule;
import dev.vaultesp.client.modules.PerformanceModule;
import dev.vaultesp.client.modules.SpawnerFinderModule;
import dev.vaultesp.client.modules.StorageESPModule;
import dev.vaultesp.client.setting.NumberSetting;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.network.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.fluid.Fluids;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.LightType;

import java.util.ArrayList;
import java.util.List;

/**
 * Ties the scanner, the modules and the renderer together.
 *
 * <p>One tick handler advances the scan under a fixed budget; one
 * {@link WorldRenderEvents#LAST} handler gathers, culls and emits the boxes; one HUD handler draws
 * the diagnostics overlay. LAST is used because Fabric guarantees the camera view matrix is already
 * installed there and every vanilla framebuffer write has finished - so disabling the depth test
 * makes the ESP read through solid rock without fighting water or weather.</p>
 */
public final class ESPPipeline {

    private static final ESPPipeline INSTANCE = new ESPPipeline();

    private static final int WORLD_MIN_Y = -64;
    private static final int WORLD_MAX_Y = 320;

    private final BlockScanner scanner = new BlockScanner();
    private final List<Command> pool = new ArrayList<>();
    private final BlockPos.Mutable lightProbe = new BlockPos.Mutable();

    private int used;
    private int drawnCount;
    private int foundCount;
    private double renderMs;
    private double scanMs;

    private ESPPipeline() {
    }

    public static ESPPipeline get() {
        return INSTANCE;
    }

    public BlockScanner scanner() {
        return scanner;
    }

    public int drawnCount() {
        return drawnCount;
    }

    public int foundCount() {
        return foundCount;
    }

    public double renderMs() {
        return renderMs;
    }

    public double scanMs() {
        return scanMs;
    }

    // ---------------------------------------------------------------- wiring

    public void register() {
        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
        WorldRenderEvents.LAST.register(this::onWorldRender);
        HudRenderCallback.EVENT.register(this::onHudRender);
        ClientPlayConnectionEvents.JOIN.register((handler, connection, client) -> scanner.clear());
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> scanner.clear());
    }

    // ---------------------------------------------------------------- tick

    private void onTick(MinecraftClient mc) {
        ModuleManager modules = ModuleManager.get();

        for (Module module : modules.all()) {
            if (module.isEnabled()) {
                module.onTick();
            }
        }

        StorageESPModule storage = modules.get(StorageESPModule.class);
        SpawnerFinderModule spawner = modules.get(SpawnerFinderModule.class);
        AncientDebrisESPModule debris = modules.get(AncientDebrisESPModule.class);
        PerformanceModule perf = modules.get(PerformanceModule.class);

        boolean storageActive = storage.isEnabled() && storage.anyTypeEnabled();
        boolean spawnerActive = spawner.isEnabled();
        boolean debrisActive = debris.isEnabled();

        if (!storageActive && !spawnerActive && !debrisActive) {
            if (scanner.size() != 0) {
                scanner.clear();
            }
            scanMs = 0d;
            foundCount = 0;
            return;
        }

        // Union of the Y bands the active modules care about. Debris alone can clamp hard,
        // which is where the smartYRange setting earns its keep.
        int minY = Integer.MAX_VALUE;
        int maxY = Integer.MIN_VALUE;
        if (storageActive || spawnerActive) {
            minY = WORLD_MIN_Y;
            maxY = WORLD_MAX_Y;
        }
        if (debrisActive) {
            minY = Math.min(minY, debris.scanMinY());
            maxY = Math.max(maxY, debris.scanMaxY());
        }
        if (minY > maxY) {
            minY = WORLD_MIN_Y;
            maxY = WORLD_MAX_Y;
        }

        long start = System.nanoTime();
        scanner.tick(mc, perf.scanRadius.getInt(), perf.chunksPerTick.getInt(), perf.rescanInterval.getInt(), minY, maxY);
        double ms = (System.nanoTime() - start) / 1e6d;
        scanMs = scanMs * 0.85d + ms * 0.15d;
    }

    // ---------------------------------------------------------------- world render

    private void onWorldRender(WorldRenderContext context) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientWorld world = context.world();
        if (world == null || mc.player == null) {
            drawnCount = 0;
            return;
        }

        ModuleManager modules = ModuleManager.get();
        StorageESPModule storage = modules.get(StorageESPModule.class);
        SpawnerFinderModule spawner = modules.get(SpawnerFinderModule.class);
        AncientDebrisESPModule debris = modules.get(AncientDebrisESPModule.class);
        PerformanceModule perf = modules.get(PerformanceModule.class);
        ClickGuiModule gui = modules.get(ClickGuiModule.class);

        boolean storageActive = storage.isEnabled() && storage.anyTypeEnabled();
        boolean spawnerActive = spawner.isEnabled();
        boolean debrisActive = debris.isEnabled();

        if ((!storageActive && !spawnerActive && !debrisActive) || scanner.size() == 0) {
            drawnCount = 0;
            return;
        }
        if (perf.skipWhileGuiOpen.isOn() && mc.currentScreen != null) {
            drawnCount = 0;
            return;
        }

        long start = System.nanoTime();

        Camera camera = context.camera();
        Vec3d cam = camera.getPos();
        Frustum frustum = context.frustum();
        boolean cull = perf.frustumCull.isOn();
        BoxRenderer.configure(context.projectionMatrix().m11, mc.getWindow().getScaledHeight());

        double now = System.currentTimeMillis() / 1000d;
        boolean inLava = debris.hideInLava.isOn()
                && world.getFluidState(mc.player.getBlockPos().up()).isOf(Fluids.LAVA);

        used = 0;
        foundCount = 0;
        int limit = Math.min(scanner.size(), perf.maxTargets.getInt());

        for (int i = 0; i < scanner.size() && used < limit; i++) {
            long packed = scanner.pos(i);
            byte type = scanner.type(i);
            int x = BlockPos.unpackLongX(packed);
            int y = BlockPos.unpackLongY(packed);
            int z = BlockPos.unpackLongZ(packed);

            Command command = acquire();
            if (!populate(command, type, x, y, z, cam, world, storage, spawner, debris,
                    storageActive, spawnerActive, debrisActive, now, inLava)) {
                continue;
            }
            if (cull && frustum != null && !frustum.isVisible(new Box(x, y, z, x + 1.0d, y + 1.0d, z + 1.0d))) {
                continue;
            }
            used++;
            foundCount++;
        }

        drawnCount = used;
        if (used == 0) {
            renderMs = renderMs * 0.85d;
            return;
        }

        BoxRenderer.setupGl();

        BufferBuilder buffer = BoxRenderer.beginQuads();
        for (int i = 0; i < used; i++) {
            Command c = pool.get(i);
            if (c.fill) {
                BoxRenderer.fill(buffer, c.x0, c.y0, c.z0, c.x1, c.y1, c.z1, c.fillColor);
            }
        }
        BoxRenderer.flush(buffer);

        buffer = BoxRenderer.beginQuads();
        for (int i = 0; i < used; i++) {
            Command c = pool.get(i);
            if (c.outline) {
                BoxRenderer.outline(buffer, c.x0, c.y0, c.z0, c.x1, c.y1, c.z1, c.lineColor, c.width);
            }
        }
        BoxRenderer.flush(buffer);

        buffer = BoxRenderer.beginQuads();
        for (int i = 0; i < used; i++) {
            Command c = pool.get(i);
            if (c.tracer) {
                BoxRenderer.tracer(buffer, c.tx, c.ty, c.tz, c.tracerColor, c.tracerWidth, 0.95f, 0f);
            }
        }
        BoxRenderer.flush(buffer);

        BoxRenderer.restoreGl();

        double ms = (System.nanoTime() - start) / 1e6d;
        renderMs = renderMs * 0.85d + ms * 0.15d;
    }

    /** Grow-only pool: no allocation in the render loop. */
    private Command acquire() {
        if (used < pool.size()) {
            return pool.get(used);
        }
        Command command = new Command();
        pool.add(command);
        return command;
    }

    private boolean populate(Command c, byte type, int x, int y, int z, Vec3d cam, ClientWorld world,
                             StorageESPModule storage, SpawnerFinderModule spawner, AncientDebrisESPModule debris,
                             boolean storageActive, boolean spawnerActive, boolean debrisActive,
                             double now, boolean inLava) {
        int argb = 0;
        float width = 2f;
        RenderMode mode = RenderMode.OUTLINE;
        double range = 64d;
        boolean tracersOn = false;
        float tracerWidth = 1f;
        boolean fade = true;
        boolean pulseOn = false;
        double pulseHz = 2d;
        float extraAlpha = 1f;
        boolean handled = false;

        switch (type) {
            case BlockScanner.TYPE_SPAWNER: {
                if (!spawnerActive) {
                    return false;
                }
                if (spawner.onlyWhenDark.isOn()
                        && world.getLightLevel(LightType.BLOCK, lightProbe.set(x, y, z)) > 7) {
                    return false;
                }
                argb = spawner.color.getArgb();
                width = spawner.lineWidth.getFloat();
                mode = spawner.mode.get();
                range = spawner.range.get();
                tracersOn = spawner.tracers.isOn();
                tracerWidth = spawner.tracerWidth.getFloat();
                fade = spawner.distanceFade.isOn();
                pulseOn = spawner.pulse.isOn();
                pulseHz = spawner.pulseSpeed.get();
                handled = true;
                break;
            }
            case BlockScanner.TYPE_DEBRIS: {
                if (!debrisActive || !debris.inRenderBand(y)) {
                    return false;
                }
                argb = debris.color.getArgb();
                width = debris.lineWidth.getFloat();
                mode = debris.mode.get();
                range = debris.range.get();
                tracersOn = debris.tracers.isOn();
                tracerWidth = debris.tracerWidth.getFloat();
                fade = debris.distanceFade.isOn();
                pulseOn = debris.pulse.isOn();
                pulseHz = debris.pulseSpeed.get();
                if (inLava) {
                    extraAlpha = 0.5f;
                }
                handled = true;
                break;
            }
            default: {
                if (!storageActive || !storage.shows(type)) {
                    return false;
                }
                argb = storage.colorFor(type).getArgb();
                width = storage.widthFor(type).getFloat();
                mode = storage.modeFor(type).get();
                range = storage.range.get();
                tracersOn = storage.tracers.isOn();
                tracerWidth = storage.tracerWidth.getFloat();
                fade = storage.distanceFade.isOn();
                pulseOn = storage.pulse.isOn();
                pulseHz = 2.4d;
                handled = true;
                break;
            }
        }

        if (!handled) {
            return false;
        }

        double dx = x + 0.5d - cam.x;
        double dy = y + 0.5d - cam.y;
        double dz = z + 0.5d - cam.z;
        double distanceSq = dx * dx + dy * dy + dz * dz;
        if (distanceSq > range * range) {
            return false;
        }
        double distance = Math.sqrt(distanceSq);

        float alphaScale = extraAlpha;
        if (fade) {
            double fadeStart = range * 0.75d;
            if (distance > fadeStart) {
                alphaScale *= (float) Math.max(0d, (range - distance) / Math.max(0.001d, range - fadeStart));
            }
        }
        if (pulseOn) {
            alphaScale *= (float) (0.72d + 0.28d * (0.5d + 0.5d * Math.sin(now * pulseHz * Math.PI * 2d)));
        }
        if (alphaScale <= 0.004f) {
            return false;
        }

        c.x0 = x - cam.x;
        c.y0 = y - cam.y;
        c.z0 = z - cam.z;
        c.x1 = c.x0 + 1d;
        c.y1 = c.y0 + 1d;
        c.z1 = c.z0 + 1d;
        c.tx = dx;
        c.ty = dy;
        c.tz = dz;
        c.width = width;
        c.tracerWidth = tracerWidth;
        c.fill = mode.drawsFill();
        c.outline = mode.drawsOutline();
        c.tracer = tracersOn;
        c.lineColor = BoxRenderer.scaleAlpha(argb, alphaScale);
        // Fill sits under the outline so the edge stays readable; a pure FILL mode keeps full alpha.
        c.fillColor = mode == RenderMode.FILL
                ? BoxRenderer.scaleAlpha(argb, alphaScale)
                : BoxRenderer.scaleAlpha(argb, alphaScale * 0.42f);
        c.tracerColor = BoxRenderer.scaleAlpha(argb, alphaScale);
        return true;
    }

    // ---------------------------------------------------------------- HUD

    private void onHudRender(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.textRenderer == null) {
            return;
        }
        HudModule hud = ModuleManager.get().get(HudModule.class);
        if (!hud.isEnabled()) {
            return;
        }

        List<String> lines = new ArrayList<>(6);
        ModuleManager modules = ModuleManager.get();

        StorageESPModule storage = modules.get(StorageESPModule.class);
        if (storage.isEnabled() && storage.anyTypeEnabled()) {
            lines.add("StorageESP " + countFamilies(storage));
        }
        SpawnerFinderModule spawner = modules.get(SpawnerFinderModule.class);
        if (spawner.isEnabled()) {
            lines.add("SpawnerFinder " + scanner.count(BlockScanner.TYPE_SPAWNER));
        }
        AncientDebrisESPModule debris = modules.get(AncientDebrisESPModule.class);
        if (debris.isEnabled()) {
            lines.add("AncientDebrisESP " + scanner.count(BlockScanner.TYPE_DEBRIS));
        }
        if (lines.isEmpty()) {
            return;
        }

        if (hud.showCounts.isOn()) {
            lines.add("drawn " + drawnCount + " / found " + scanner.size());
        }
        if (hud.showTimings.isOn()) {
            lines.add(String.format(java.util.Locale.ROOT, "scan %.2f ms | render %.2f ms", scanMs, renderMs));
        }
        if (hud.showScanStats.isOn()) {
            lines.add("sections " + scanner.sectionsScanned() + " walked / " + scanner.sectionsRejected() + " rejected");
        }

        int argb = hud.color.getArgb();
        float scale = hud.scale.getFloat();
        int lineHeight = (int) (11 * scale);
        int margin = hud.margin.getInt();
        int width = (int) (longestLine(mc, lines) * scale) + (int) (12 * scale);
        int height = lineHeight * lines.size() + (int) (8 * scale);

        int windowWidth = (int) mc.getWindow().getScaledWidth();
        int windowHeight = (int) mc.getWindow().getScaledHeight();
        HudModule.Position position = hud.position.get();

        int boxX = position == HudModule.Position.TOP_RIGHT || position == HudModule.Position.BOTTOM_RIGHT
                ? windowWidth - width - margin : margin;
        int boxY = position == HudModule.Position.BOTTOM_LEFT || position == HudModule.Position.BOTTOM_RIGHT
                ? windowHeight - height - margin : margin;

        context.fill(boxX, boxY, boxX + width, boxY + height, 0xB00A0E14);
        context.fill(boxX, boxY, boxX + 1, boxY + height, argb);

        int textY = boxY + (int) (4 * scale);
        for (String line : lines) {
            context.getMatrices().push();
            context.getMatrices().translate(boxX + (int) (6 * scale), textY, 0);
            context.getMatrices().scale(scale, scale, 1f);
            context.drawText(mc.textRenderer, line, 0, 0, argb, true);
            context.getMatrices().pop();
            textY += lineHeight;
        }
    }

    private static String countFamilies(StorageESPModule storage) {
        int total = 0;
        if (storage.chests.isOn()) {
            total += ESPPipeline.get().scanner.count(BlockScanner.TYPE_CHEST);
        }
        if (storage.hoppers.isOn()) {
            total += ESPPipeline.get().scanner.count(BlockScanner.TYPE_HOPPER);
        }
        if (storage.shulkerBoxes.isOn()) {
            total += ESPPipeline.get().scanner.count(BlockScanner.TYPE_SHULKER);
        }
        if (storage.barrels.isOn()) {
            total += ESPPipeline.get().scanner.count(BlockScanner.TYPE_BARREL);
        }
        if (storage.enderChests.isOn()) {
            total += ESPPipeline.get().scanner.count(BlockScanner.TYPE_ENDER);
        }
        return Integer.toString(total);
    }

    private static int longestLine(MinecraftClient mc, List<String> lines) {
        int best = 0;
        for (String line : lines) {
            best = Math.max(best, mc.textRenderer.getWidth(line));
        }
        return best;
    }

    /** One pooled draw instruction per visible target. */
    private static final class Command {
        double x0;
        double y0;
        double z0;
        double x1;
        double y1;
        double z1;
        double tx;
        double ty;
        double tz;
        int fillColor;
        int lineColor;
        int tracerColor;
        float width;
        float tracerWidth;
        boolean fill;
        boolean outline;
        boolean tracer;
    }

}