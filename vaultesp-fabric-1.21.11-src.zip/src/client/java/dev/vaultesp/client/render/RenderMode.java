package dev.vaultesp.client.render;

import dev.vaultesp.client.setting.EnumSetting;

/** How a highlighted block is painted. Every ESP module has one of these per block type. */
public enum RenderMode implements EnumSetting.Labeled {

    OUTLINE("Outline"),
    FILL("Fill"),
    OUTLINE_FILL("Outline + Fill"),
    GLOW("Glow (pulsing)");

    private final String label;

    RenderMode(String label) {
        this.label = label;
    }

    @Override
    public String label() {
        return label;
    }

    public boolean drawsOutline() {
        return this == OUTLINE || this == OUTLINE_FILL || this == GLOW;
    }

    public boolean drawsFill() {
        return this == FILL || this == OUTLINE_FILL || this == GLOW;
    }

    /** Glow animates both layers; fill is halved so the outline stays readable. */
    public boolean pulses() {
        return this == GLOW;
    }
}