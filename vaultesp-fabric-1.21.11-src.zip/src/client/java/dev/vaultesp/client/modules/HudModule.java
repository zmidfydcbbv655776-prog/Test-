package dev.vaultesp.client.modules;

import dev.vaultesp.client.module.Category;
import dev.vaultesp.client.module.Module;
import dev.vaultesp.client.setting.BooleanSetting;
import dev.vaultesp.client.setting.ColorSetting;
import dev.vaultesp.client.setting.EnumSetting;
import dev.vaultesp.client.setting.NumberSetting;

/**
 * Small in-game overlay listing which ESP modules are live, how many targets each found,
 * and the smoothed scan / render cost in milliseconds.
 */
public class HudModule extends Module {

    public enum Position implements EnumSetting.Labeled {
        TOP_LEFT("Top Left"),
        TOP_RIGHT("Top Right"),
        BOTTOM_LEFT("Bottom Left"),
        BOTTOM_RIGHT("Bottom Right");

        private final String label;

        Position(String label) {
            this.label = label;
        }

        @Override
        public String label() {
            return label;
        }
    }

    public final BooleanSetting showCounts = add(new BooleanSetting("showCounts", "Show Target Counts", true));
    public final BooleanSetting showTimings = add(new BooleanSetting("showTimings", "Show Timings", true)
            .describe("Smoothed scan and render cost. Useful for proving the ESP is not your frame time."));
    public final BooleanSetting showScanStats = add(new BooleanSetting("showScanStats", "Show Scanner Stats", false)
            .describe("Sections rejected by palette filtering vs sections actually walked."));
    public final ColorSetting color = add(new ColorSetting("color", "HUD Color", 0xFFE8EEF6));
    public final NumberSetting scale = add(new NumberSetting("scale", "HUD Scale", 1.0d, 0.6d, 2.0d, 0.1d, "x"));
    public final EnumSetting<Position> position = add(new EnumSetting<>("position", "Position", Position.BOTTOM_LEFT));
    public final NumberSetting margin = add(new NumberSetting("margin", "Screen Margin", 6d, 0d, 40d, 1d, " px"));

    public HudModule() {
        super("HUD",
                "Compact overlay with live ESP target counts and frame cost.",
                Category.CLIENT, 0xFFB6E84A);
    }
}