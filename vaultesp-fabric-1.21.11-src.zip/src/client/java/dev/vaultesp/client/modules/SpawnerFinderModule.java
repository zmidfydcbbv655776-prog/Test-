package dev.vaultesp.client.modules;

import dev.vaultesp.client.module.Category;
import dev.vaultesp.client.module.Module;
import dev.vaultesp.client.render.RenderMode;
import dev.vaultesp.client.setting.BooleanSetting;
import dev.vaultesp.client.setting.ColorSetting;
import dev.vaultesp.client.setting.EnumSetting;
import dev.vaultesp.client.setting.NumberSetting;

/**
 * Highlights mob spawners through the world.
 *
 * <p>Spawners hide in dark, enclosed rooms, so the defaults are deliberately loud: a 3 px rose
 * outline, a translucent fill, a slow pulse and a tracer. Depth testing is disabled for the whole
 * ESP pass, so bedrock, lava and gravel never occlude the box.</p>
 */
public class SpawnerFinderModule extends Module {

    public final ColorSetting color = add(new ColorSetting("color", "Spawner Color", 0xFFFF4D6A)
            .describe("ARGB. The alpha channel drives fill and outline transparency."));
    public final NumberSetting lineWidth = add(new NumberSetting("lineWidth", "Outline Width", 3.0d, 0.5d, 10d, 0.25d, " px")
            .describe("Constant in screen pixels at any distance."));
    public final EnumSetting<RenderMode> mode = add(new EnumSetting<>("mode", "Render Mode", RenderMode.GLOW));
    public final NumberSetting range = add(new NumberSetting("range", "Render Range", 64d, 16d, 160d, 8d, " blocks"));
    public final BooleanSetting pulse = add(new BooleanSetting("pulse", "Pulse", true)
            .describe("Breathes the alpha between 0.72 and 1.0 at roughly 2.4 Hz."));
    public final NumberSetting pulseSpeed = add(new NumberSetting("pulseSpeed", "Pulse Speed", 2.4d, 0.2d, 8d, 0.1d, " Hz"));
    public final BooleanSetting tracers = add(new BooleanSetting("tracers", "Tracers", true));
    public final NumberSetting tracerWidth = add(new NumberSetting("tracerWidth", "Tracer Width", 1.2d, 0.5d, 5d, 0.1d, " px"));
    public final BooleanSetting distanceFade = add(new BooleanSetting("distanceFade", "Distance Fade", true));
    public final BooleanSetting onlyWhenDark = add(new BooleanSetting("onlyWhenDark", "Hide In Daylight", false)
            .describe("Skips spawners whose block light is above 7 - they cannot spawn anyway."));

    public SpawnerFinderModule() {
        super("SpawnerFinder",
                "Finds mob spawners in loaded chunks and outlines them through walls with a configurable colour and thickness.",
                Category.WORLD, 0xFFFF5C7A);

        pulseSpeed.visibleWhen(pulse::isOn);
        tracerWidth.visibleWhen(tracers::isOn);
    }

    @Override
    protected void onEnable() {
        dev.vaultesp.client.render.ESPPipeline.get().scanner().invalidateYRange();
    }
}