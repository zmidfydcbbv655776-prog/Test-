package dev.vaultesp.client.modules;

import dev.vaultesp.client.module.Category;
import dev.vaultesp.client.module.Module;
import dev.vaultesp.client.render.RenderMode;
import dev.vaultesp.client.setting.BooleanSetting;
import dev.vaultesp.client.setting.ColorSetting;
import dev.vaultesp.client.setting.EnumSetting;
import dev.vaultesp.client.setting.NumberSetting;

/**
 * Highlights ancient debris while strip-mining the Nether.
 *
 * <p>{@code smartYRange} is the performance switch: debris only generates between Y 8 and Y 22
 * (with a smaller band down to Y −8), so clamping the section scan to that band lets the scanner
 * reject the vast majority of a Nether chunk before it reads a single block.</p>
 */
public class AncientDebrisESPModule extends Module {

    public final ColorSetting color = add(new ColorSetting("color", "Debris Color", 0xFF2FE0C0)
            .describe("Teal reads clearly against netherrack and basalt. Alpha drives transparency."));
    public final NumberSetting lineWidth = add(new NumberSetting("lineWidth", "Outline Width", 2.5d, 0.5d, 10d, 0.25d, " px"));
    public final EnumSetting<RenderMode> mode = add(new EnumSetting<>("mode", "Render Mode", RenderMode.OUTLINE_FILL));
    public final NumberSetting range = add(new NumberSetting("range", "Render Range", 48d, 16d, 128d, 8d, " blocks"));

    public final BooleanSetting smartYRange = add(new BooleanSetting("smartYRange", "Smart Y Range", true)
            .describe("Clamps the scan to Y -8 .. 32, where debris can actually generate. Large speed win."));
    public final NumberSetting minY = add(new NumberSetting("minY", "Min Y", 8d, -64d, 320d, 1d, "")
            .describe("Render filter. Blocks below this are ignored."));
    public final NumberSetting maxY = add(new NumberSetting("maxY", "Max Y", 22d, -64d, 320d, 1d, "")
            .describe("Render filter. Blocks above this are ignored."));

    public final BooleanSetting pulse = add(new BooleanSetting("pulse", "Pulse", false));
    public final NumberSetting pulseSpeed = add(new NumberSetting("pulseSpeed", "Pulse Speed", 1.8d, 0.2d, 8d, 0.1d, " Hz"));
    public final BooleanSetting tracers = add(new BooleanSetting("tracers", "Tracers", false));
    public final NumberSetting tracerWidth = add(new NumberSetting("tracerWidth", "Tracer Width", 1.0d, 0.5d, 5d, 0.1d, " px"));
    public final BooleanSetting distanceFade = add(new BooleanSetting("distanceFade", "Distance Fade", true));
    public final BooleanSetting hideInLava = add(new BooleanSetting("hideInLava", "Dim Inside Lava", true)
            .describe("Halves the alpha when your camera is submerged, so the screen does not turn into noise."));

    public AncientDebrisESPModule() {
        super("AncientDebrisESP",
                "Outlines ancient debris through netherrack. Toggle it on, set a Y band and strip-mine without guessing.",
                Category.WORLD, 0xFF2FE0C0);

        minY.visibleWhen(() -> !smartYRange.isOn());
        maxY.visibleWhen(() -> !smartYRange.isOn());
        pulseSpeed.visibleWhen(pulse::isOn);
        tracerWidth.visibleWhen(tracers::isOn);
    }

    /** Lowest Y the scanner has to visit for this module. */
    public int scanMinY() {
        return smartYRange.isOn() ? -8 : minY.getInt();
    }

    /** Highest Y the scanner has to visit for this module. */
    public int scanMaxY() {
        return smartYRange.isOn() ? 32 : maxY.getInt();
    }

    /** Render-time filter, independent of the scan band. */
    public boolean inRenderBand(int y) {
        int lo = smartYRange.isOn() ? Integer.MIN_VALUE : minY.getInt();
        int hi = smartYRange.isOn() ? Integer.MAX_VALUE : maxY.getInt();
        return y >= lo && y <= hi;
    }

    @Override
    protected void onEnable() {
        dev.vaultesp.client.render.ESPPipeline.get().scanner().invalidateYRange();
    }

    @Override
    protected void onDisable() {
        dev.vaultesp.client.render.ESPPipeline.get().scanner().invalidateYRange();
    }
}