package dev.vaultesp.client.modules;

import dev.vaultesp.client.module.Category;
import dev.vaultesp.client.module.Module;
import dev.vaultesp.client.setting.BooleanSetting;
import dev.vaultesp.client.setting.ColorSetting;
import dev.vaultesp.client.setting.NumberSetting;

/**
 * Owns the look of the ClickGUI itself. Every value here is pushed into
 * {@link dev.vaultesp.client.gui.Theme} at the top of each GUI frame, so changes preview live
 * while the screen is open - including the accent colour, which recolours the panel you are editing.
 */
public class ClickGuiModule extends Module {

    public final ColorSetting accentColor = add(new ColorSetting("accentColor", "Accent Color", 0xFFFFB020)
            .describe("Panel bars, active toggles, slider fills and the search caret."));
    public final NumberSetting scale = add(new NumberSetting("scale", "GUI Scale", 1.0d, 0.7d, 1.8d, 0.05d, "x"));
    public final NumberSetting backgroundDim = add(new NumberSetting("backgroundDim", "Background Dim", 0.55d, 0d, 0.95d, 0.05d, "")
            .describe("How much of the world is darkened behind the panels. 0 keeps the world fully visible."));
    public final BooleanSetting animations = add(new BooleanSetting("animations", "Animations", true)
            .describe("Panel open/close easing and row hover transitions."));
    public final BooleanSetting showDescriptions = add(new BooleanSetting("showDescriptions", "Show Descriptions", true));
    public final BooleanSetting showKeybinds = add(new BooleanSetting("showKeybinds", "Show Keybinds", true));
    public final BooleanSetting closeOnUnfocus = add(new BooleanSetting("closeOnUnfocus", "Close On Lost Focus", false)
            .describe("Closes the GUI when the window loses focus."));

    public ClickGuiModule() {
        super("ClickGUI",
                "Appearance and behaviour of this screen. The module is always reachable with RIGHT SHIFT or /vaultesp open.",
                Category.CLIENT, 0xFF4CC4FF);
        setEnabled(true);
    }

    /** The GUI never actually switches off - the bind closes the screen instead. */
    @Override
    public void setEnabled(boolean value) {
        super.setEnabled(true);
    }

    @Override
    public int getBind() {
        return super.getBind();
    }
}