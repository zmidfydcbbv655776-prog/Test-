package dev.vaultesp.client.modules;

import dev.vaultesp.client.module.Category;
import dev.vaultesp.client.module.Module;
import dev.vaultesp.client.render.BlockScanner;
import dev.vaultesp.client.render.RenderMode;
import dev.vaultesp.client.setting.BooleanSetting;
import dev.vaultesp.client.setting.ColorSetting;
import dev.vaultesp.client.setting.EnumSetting;
import dev.vaultesp.client.setting.NumberSetting;

/**
 * Highlights storage blocks. Five families, each with its own enable flag, ARGB colour
 * (alpha included, so transparency is per-type), pixel outline width and render mode.
 *
 * <p>Trapped chests are covered by {@code chests} because {@code TrappedChestBlock extends ChestBlock};
 * all seventeen shulker boxes are covered by {@code shulkerBoxes} because they are all
 * {@code ShulkerBoxBlock} instances.</p>
 */
public class StorageESPModule extends Module {

    // ---- chests (includes trapped chests) -------------------------------------
    public final BooleanSetting chests = add(new BooleanSetting("chests", "Chests", true)
            .describe("Normal and trapped chests."));
    public final ColorSetting chestColor = add(new ColorSetting("chestColor", "Chest Color", 0xFFFFAA00));
    public final NumberSetting chestWidth = add(new NumberSetting("chestWidth", "Chest Width", 2.0d, 0.5d, 8d, 0.25d, " px"));
    public final EnumSetting<RenderMode> chestMode = add(new EnumSetting<>("chestMode", "Chest Mode", RenderMode.OUTLINE_FILL));

    // ---- hoppers --------------------------------------------------------------
    public final BooleanSetting hoppers = add(new BooleanSetting("hoppers", "Hoppers", true));
    public final ColorSetting hopperColor = add(new ColorSetting("hopperColor", "Hopper Color", 0xFF9AA7B5));
    public final NumberSetting hopperWidth = add(new NumberSetting("hopperWidth", "Hopper Width", 1.5d, 0.5d, 8d, 0.25d, " px"));
    public final EnumSetting<RenderMode> hopperMode = add(new EnumSetting<>("hopperMode", "Hopper Mode", RenderMode.OUTLINE));

    // ---- shulker boxes --------------------------------------------------------
    public final BooleanSetting shulkerBoxes = add(new BooleanSetting("shulkerBoxes", "Shulker Boxes", true));
    public final ColorSetting shulkerColor = add(new ColorSetting("shulkerColor", "Shulker Color", 0xFFFF5CD7));
    public final NumberSetting shulkerWidth = add(new NumberSetting("shulkerWidth", "Shulker Width", 2.5d, 0.5d, 8d, 0.25d, " px"));
    public final EnumSetting<RenderMode> shulkerMode = add(new EnumSetting<>("shulkerMode", "Shulker Mode", RenderMode.OUTLINE_FILL));

    // ---- barrels --------------------------------------------------------------
    public final BooleanSetting barrels = add(new BooleanSetting("barrels", "Barrels", false));
    public final ColorSetting barrelColor = add(new ColorSetting("barrelColor", "Barrel Color", 0xFFC98B4B));
    public final NumberSetting barrelWidth = add(new NumberSetting("barrelWidth", "Barrel Width", 1.75d, 0.5d, 8d, 0.25d, " px"));
    public final EnumSetting<RenderMode> barrelMode = add(new EnumSetting<>("barrelMode", "Barrel Mode", RenderMode.OUTLINE));

    // ---- ender chests ---------------------------------------------------------
    public final BooleanSetting enderChests = add(new BooleanSetting("enderChests", "Ender Chests", false));
    public final ColorSetting enderColor = add(new ColorSetting("enderColor", "Ender Chest Color", 0xFF4CC4FF));
    public final NumberSetting enderWidth = add(new NumberSetting("enderWidth", "Ender Chest Width", 2.0d, 0.5d, 8d, 0.25d, " px"));
    public final EnumSetting<RenderMode> enderMode = add(new EnumSetting<>("enderMode", "Ender Chest Mode", RenderMode.OUTLINE_FILL));

    // ---- module wide ----------------------------------------------------------
    public final NumberSetting range = add(new NumberSetting("range", "Render Range", 96d, 16d, 160d, 8d, " blocks")
            .describe("Capped by the Performance module's scan radius."));
    public final BooleanSetting tracers = add(new BooleanSetting("tracers", "Tracers", false)
            .describe("Draws an alpha-graded ribbon from the camera to each block."));
    public final NumberSetting tracerWidth = add(new NumberSetting("tracerWidth", "Tracer Width", 1.2d, 0.5d, 5d, 0.1d, " px"));
    public final BooleanSetting distanceFade = add(new BooleanSetting("distanceFade", "Distance Fade", true)
            .describe("Fades the last 25% of the range out instead of popping."));
    public final BooleanSetting pulse = add(new BooleanSetting("pulse", "Pulse", false));

    public StorageESPModule() {
        super("StorageESP",
                "Highlights chests, hoppers, shulker boxes, barrels and ender chests with per-type colour, alpha and outline width.",
                Category.RENDER, 0xFFFFB020);

        // Colour / width / mode only make sense while their family is switched on.
        chestColor.visibleWhen(chests::isOn);
        chestWidth.visibleWhen(chests::isOn);
        chestMode.visibleWhen(chests::isOn);
        hopperColor.visibleWhen(hoppers::isOn);
        hopperWidth.visibleWhen(hoppers::isOn);
        hopperMode.visibleWhen(hoppers::isOn);
        shulkerColor.visibleWhen(shulkerBoxes::isOn);
        shulkerWidth.visibleWhen(shulkerBoxes::isOn);
        shulkerMode.visibleWhen(shulkerBoxes::isOn);
        barrelColor.visibleWhen(barrels::isOn);
        barrelWidth.visibleWhen(barrels::isOn);
        barrelMode.visibleWhen(barrels::isOn);
        enderColor.visibleWhen(enderChests::isOn);
        enderWidth.visibleWhen(enderChests::isOn);
        enderMode.visibleWhen(enderChests::isOn);
        tracerWidth.visibleWhen(tracers::isOn);
    }

    public boolean anyTypeEnabled() {
        return chests.isOn() || hoppers.isOn() || shulkerBoxes.isOn() || barrels.isOn() || enderChests.isOn();
    }

    /** Fast dispatch used by the renderer: is this scanner type flag handled by this module? */
    public boolean shows(byte type) {
        return switch (type) {
            case BlockScanner.TYPE_CHEST -> chests.isOn();
            case BlockScanner.TYPE_HOPPER -> hoppers.isOn();
            case BlockScanner.TYPE_SHULKER -> shulkerBoxes.isOn();
            case BlockScanner.TYPE_BARREL -> barrels.isOn();
            case BlockScanner.TYPE_ENDER -> enderChests.isOn();
            default -> false;
        };
    }

    public ColorSetting colorFor(byte type) {
        return switch (type) {
            case BlockScanner.TYPE_HOPPER -> hopperColor;
            case BlockScanner.TYPE_SHULKER -> shulkerColor;
            case BlockScanner.TYPE_BARREL -> barrelColor;
            case BlockScanner.TYPE_ENDER -> enderColor;
            default -> chestColor;
        };
    }

    public NumberSetting widthFor(byte type) {
        return switch (type) {
            case BlockScanner.TYPE_HOPPER -> hopperWidth;
            case BlockScanner.TYPE_SHULKER -> shulkerWidth;
            case BlockScanner.TYPE_BARREL -> barrelWidth;
            case BlockScanner.TYPE_ENDER -> enderWidth;
            default -> chestWidth;
        };
    }

    public EnumSetting<RenderMode> modeFor(byte type) {
        return switch (type) {
            case BlockScanner.TYPE_HOPPER -> hopperMode;
            case BlockScanner.TYPE_SHULKER -> shulkerMode;
            case BlockScanner.TYPE_BARREL -> barrelMode;
            case BlockScanner.TYPE_ENDER -> enderMode;
            default -> chestMode;
        };
    }
}