package dev.vaultesp.client.modules;

import dev.vaultesp.client.module.Category;
import dev.vaultesp.client.module.Module;
import dev.vaultesp.client.setting.BooleanSetting;
import dev.vaultesp.client.setting.NumberSetting;

/**
 * The frame-time budget for the whole ESP system. These are the knobs to reach for first if a
 * heavy world starts to stutter: drop {@code chunksPerTick}, raise {@code rescanInterval},
 * or lower {@code scanRadius}.
 */
public class PerformanceModule extends Module {

    public final NumberSetting scanRadius = add(new NumberSetting("scanRadius", "Scan Radius", 96d, 16d, 160d, 8d, " blocks")
            .describe("Half width of the square area the scanner walks. Modules cannot render beyond this."));
    public final NumberSetting chunksPerTick = add(new NumberSetting("chunksPerTick", "Chunks Per Tick", 6d, 1d, 24d, 1d, "")
            .describe("The scanner's per-tick budget. Lower spreads a pass over more ticks."));
    public final NumberSetting rescanInterval = add(new NumberSetting("rescanInterval", "Rescan Interval", 20d, 5d, 200d, 5d, " ticks")
            .describe("Ticks between full re-scans. 20 ticks = one second of staleness for placed/broken blocks."));
    public final NumberSetting maxTargets = add(new NumberSetting("maxTargets", "Max Targets", 2048d, 64d, 8192d, 64d, "")
            .describe("Hard cap on boxes drawn in one frame."));
    public final BooleanSetting frustumCull = add(new BooleanSetting("frustumCull", "Frustum Culling", true)
            .describe("Skips anything outside the camera frustum before any geometry is built."));
    public final BooleanSetting skipWhileGuiOpen = add(new BooleanSetting("skipWhileGuiOpen", "Skip While GUI Open", false)
            .describe("Leaves ESP on behind the ClickGUI by default, so you can preview your colours."));

    public PerformanceModule() {
        super("Performance",
                "Scanner and renderer budgets. Always enabled - these settings apply whether or not the module is toggled on.",
                Category.CLIENT, 0xFF2FE0C0);
        setEnabled(true);
    }

    /** Performance settings always apply, so the module behaves as permanently on. */
    @Override
    public void setEnabled(boolean value) {
        super.setEnabled(true);
    }
}