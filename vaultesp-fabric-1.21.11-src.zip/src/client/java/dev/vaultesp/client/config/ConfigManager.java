package dev.vaultesp.client.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.vaultesp.VaultESP;
import dev.vaultesp.client.gui.ClickGuiScreen;
import dev.vaultesp.client.gui.Theme;
import dev.vaultesp.client.module.Category;
import dev.vaultesp.client.module.Module;
import dev.vaultesp.client.module.ModuleManager;
import dev.vaultesp.client.setting.Setting;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

/**
 * Reads and writes {@code config/vaultesp.json}.
 *
 * <p>The format is intentionally flat: every setting is stored as the exact string its
 * {@link Setting#write()} produces, which is the same string {@code /vaultesp set} accepts and the
 * same string the GUI's "Export vaultesp.json" produces. One serialisation path, so the file can
 * never drift from the GUI.</p>
 *
 * <pre>
 * {
 *   "format": 1,
 *   "modules": {
 *     "StorageESP": {
 *       "enabled": true,
 *       "bind": -1,
 *       "settings": { "chests": "true", "chestColor": "#FFFFAA00", "chestWidth": "2.0" }
 *     }
 *   },
 *   "gui": { "panels": { "Render": [12, 34, false] } }
 * }
 * </pre>
 */
public final class ConfigManager {

    public static final int FORMAT = 1;

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    private static final Map<Category, int[]> PENDING_PANELS = new HashMap<>();
    private static boolean panelHookRegistered;
    private static boolean warnedAboutFailure;

    private ConfigManager() {
    }

    public static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve(VaultESP.MOD_ID + ".json");
    }

    // ---------------------------------------------------------------- writing

    public static void save() {
        try {
            JsonObject root = new JsonObject();
            root.addProperty("format", FORMAT);

            JsonObject modules = new JsonObject();
            for (Module module : ModuleManager.get().all()) {
                JsonObject entry = new JsonObject();
                entry.addProperty("enabled", module.isEnabled());
                entry.addProperty("bind", module.getBind());

                JsonObject settings = new JsonObject();
                for (Setting<?> setting : module.getSettings()) {
                    settings.addProperty(setting.getId(), setting.write());
                }
                entry.add("settings", settings);
                modules.add(module.getName(), entry);
            }
            root.add("modules", modules);

            JsonObject gui = new JsonObject();
            JsonObject panels = new JsonObject();
            for (ClickGuiScreen.Panel panel : ClickGuiScreen.INSTANCE.panels()) {
                JsonArray geometry = new JsonArray();
                geometry.add(panel.getX());
                geometry.add(panel.getY());
                geometry.add(panel.isCollapsed());
                panels.add(panel.getCategory().name(), geometry);
            }
            gui.add("panels", panels);
            root.add("gui", gui);

            Path target = file();
            if (target.getParent() != null) {
                Files.createDirectories(target.getParent());
            }
            Files.writeString(target, GSON.toJson(root), StandardCharsets.UTF_8);
            warnedAboutFailure = false;
        } catch (Exception exception) {
            if (!warnedAboutFailure) {
                warnedAboutFailure = true;
                VaultESP.LOGGER.error("[{}] Failed to write config to {}", VaultESP.MOD_NAME, file(), exception);
            }
        }
    }

    // ---------------------------------------------------------------- reading

    public static void load() {
        Path source = file();
        if (!Files.exists(source)) {
            VaultESP.LOGGER.info("[{}] No config at {} - using defaults.", VaultESP.MOD_NAME, source);
            save();
            return;
        }
        try {
            JsonObject root = JsonParser.parseString(Files.readString(source, StandardCharsets.UTF_8)).getAsJsonObject();
            ModuleManager modules = ModuleManager.get();

            JsonElement modulesElement = root.get("modules");
            if (modulesElement != null && modulesElement.isJsonObject()) {
                for (Map.Entry<String, JsonElement> entry : modulesElement.getAsJsonObject().entrySet()) {
                    Module module = modules.byName(entry.getKey());
                    if (module == null || !entry.getValue().isJsonObject()) {
                        continue;
                    }
                    JsonObject moduleJson = entry.getValue().getAsJsonObject();

                    JsonElement enabled = moduleJson.get("enabled");
                    if (enabled != null && enabled.isJsonPrimitive()) {
                        module.setEnabled(enabled.getAsBoolean());
                    }
                    JsonElement bind = moduleJson.get("bind");
                    if (bind != null && bind.isJsonPrimitive()) {
                        module.setBind(bind.getAsInt());
                    }

                    JsonElement settings = moduleJson.get("settings");
                    if (settings != null && settings.isJsonObject()) {
                        for (Map.Entry<String, JsonElement> settingEntry : settings.getAsJsonObject().entrySet()) {
                            Setting<?> setting = module.getSetting(settingEntry.getKey());
                            if (setting != null && settingEntry.getValue().isJsonPrimitive()) {
                                setting.read(settingEntry.getValue().getAsString());
                            }
                        }
                    }
                }
            }

            JsonElement guiElement = root.get("gui");
            if (guiElement != null && guiElement.isJsonObject()) {
                JsonElement panelsElement = guiElement.getAsJsonObject().get("panels");
                if (panelsElement != null && panelsElement.isJsonObject()) {
                    for (Map.Entry<String, JsonElement> entry : panelsElement.getAsJsonObject().entrySet()) {
                        try {
                            Category category = Category.valueOf(entry.getKey());
                            JsonArray geometry = entry.getValue().getAsJsonArray();
                            if (geometry.size() >= 3) {
                                PENDING_PANELS.put(category, new int[]{
                                        geometry.get(0).getAsInt(),
                                        geometry.get(1).getAsInt(),
                                        geometry.get(2).getAsBoolean() ? 1 : 0
                                });
                            }
                        } catch (IllegalArgumentException | IllegalStateException ignored) {
                            // unknown category or malformed geometry - skip it
                        }
                    }
                }
            }

            Theme.sync();
            hookPanelRestore();
            VaultESP.LOGGER.info("[{}] Config loaded from {}", VaultESP.MOD_NAME, source);
        } catch (Exception exception) {
            VaultESP.LOGGER.error("[{}] Failed to read config at {} - keeping defaults.", VaultESP.MOD_NAME, source, exception);
        }
    }

    /**
     * Panels only exist once the GUI has been opened at least once, so stored geometry is applied
     * the first tick after that happens. Costs one boolean per tick until it fires.
     */
    private static void hookPanelRestore() {
        if (PENDING_PANELS.isEmpty() || panelHookRegistered) {
            return;
        }
        panelHookRegistered = true;
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (PENDING_PANELS.isEmpty()) {
                return;
            }
            java.util.List<ClickGuiScreen.Panel> panels = ClickGuiScreen.INSTANCE.panels();
            if (panels.isEmpty()) {
                return;
            }
            for (ClickGuiScreen.Panel panel : panels) {
                int[] geometry = PENDING_PANELS.remove(panel.getCategory());
                if (geometry != null) {
                    panel.setX(geometry[0]);
                    panel.setY(geometry[1]);
                    panel.setCollapsed(geometry[2] == 1);
                }
            }
            if (PENDING_PANELS.isEmpty()) {
                VaultESP.LOGGER.info("[{}] ClickGUI panel layout restored.", VaultESP.MOD_NAME);
            }
        });
    }
}