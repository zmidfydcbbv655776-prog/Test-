package dev.vaultesp.client.setting;

/**
 * A clamped, stepped numeric value. Used for outline width (pixels), alpha, ranges,
 * scan budgets and GUI scale.
 */
public class NumberSetting extends Setting<Double> {

    private final double min;
    private final double max;
    private final double step;
    private final String suffix;
    private final int precision;

    public NumberSetting(String id, String name, double defaultValue, double min, double max, double step, String suffix) {
        super(id, name, clamp(defaultValue, min, max));
        this.min = min;
        this.max = max;
        this.step = step <= 0 ? 1 : step;
        this.suffix = suffix == null ? "" : suffix;
        this.precision = step >= 1 ? 0 : (step >= 0.1 ? 1 : 2);
    }

    public double getMin() {
        return min;
    }

    public double getMax() {
        return max;
    }

    public double getStep() {
        return step;
    }

    public String getSuffix() {
        return suffix;
    }

    public int getPrecision() {
        return precision;
    }

    public float getFloat() {
        return get().floatValue();
    }

    public int getInt() {
        return get().intValue();
    }

    @Override
    public void set(Double newValue) {
        super.set(snap(newValue == null ? getDefault() : newValue));
    }

    /** Nudges by one step; {@code direction} may be negative. */
    public void nudge(int direction) {
        set(get() + step * direction);
    }

    public double snap(double raw) {
        if (Double.isNaN(raw) || Double.isInfinite(raw)) {
            return getDefault();
        }
        double snapped = Math.round(raw / step) * step;
        return clamp(snapped, min, max);
    }

    /** 0..1 position of the current value inside its range - what the slider fills to. */
    public double ratio() {
        if (max <= min) {
            return 0;
        }
        return (get() - min) / (max - min);
    }

    public String format() {
        return String.format(java.util.Locale.ROOT, "%." + precision + "f%s", get(), suffix);
    }

    private static double clamp(double value, double lo, double hi) {
        return value < lo ? lo : (Math.min(value, hi));
    }

    @Override
    public String write() {
        return Double.toString(get());
    }

    @Override
    public void read(String raw) {
        if (raw == null) {
            return;
        }
        try {
            set(Double.parseDouble(raw.trim()));
        } catch (RuntimeException ignored) {
            // leave the current value untouched
        }
    }
}