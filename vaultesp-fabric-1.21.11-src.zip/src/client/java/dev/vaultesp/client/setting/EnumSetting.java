package dev.vaultesp.client.setting;

/** A cycle-through enum. Left click advances, shift + left click goes backwards. */
public class EnumSetting<E extends Enum<E>> extends Setting<E> {

    private final E[] values;

    public EnumSetting(String id, String name, E defaultValue) {
        super(id, name, defaultValue);
        this.values = defaultValue.getDeclaringClass().getEnumConstants();
    }

    public E[] getValues() {
        return values;
    }

    public void cycle(int direction) {
        int index = index();
        int next = ((index + direction) % values.length + values.length) % values.length;
        set(values[next]);
    }

    public int index() {
        E current = get();
        for (int i = 0; i < values.length; i++) {
            if (values[i] == current) {
                return i;
            }
        }
        return 0;
    }

    /** Display label. Falls back to the constant name when the enum carries no label. */
    public String label() {
        E current = get();
        if (current instanceof Labeled labeled) {
            return labeled.label();
        }
        return current.name();
    }

    /** Implement on any enum used by this setting to get pretty names in the GUI. */
    public interface Labeled {
        String label();
    }

    @Override
    public String write() {
        return get().name();
    }

    @Override
    public void read(String raw) {
        if (raw == null) {
            return;
        }
        String trimmed = raw.trim();
        for (E candidate : values) {
            if (candidate.name().equalsIgnoreCase(trimmed)) {
                set(candidate);
                return;
            }
            if (candidate instanceof Labeled labeled && labeled.label().equalsIgnoreCase(trimmed)) {
                set(candidate);
                return;
            }
        }
    }
}