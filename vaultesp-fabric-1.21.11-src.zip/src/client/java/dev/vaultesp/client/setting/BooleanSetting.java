package dev.vaultesp.client.setting;

/** A toggle. Rendered as a pill switch in the ClickGUI. */
public class BooleanSetting extends Setting<Boolean> {

    public BooleanSetting(String id, String name, boolean defaultValue) {
        super(id, name, defaultValue);
    }

    public boolean isOn() {
        return get();
    }

    public void toggle() {
        set(!isOn());
    }

    @Override
    public String write() {
        return Boolean.toString(isOn());
    }

    @Override
    public void read(String raw) {
        if (raw == null) {
            return;
        }
        String trimmed = raw.trim();
        if (trimmed.equalsIgnoreCase("true") || trimmed.equals("1") || trimmed.equalsIgnoreCase("on")) {
            set(true);
        } else if (trimmed.equalsIgnoreCase("false") || trimmed.equals("0") || trimmed.equalsIgnoreCase("off")) {
            set(false);
        } else {
            // Anything unparseable flips the current value, matching chat-command expectations.
            toggle();
        }
    }
}