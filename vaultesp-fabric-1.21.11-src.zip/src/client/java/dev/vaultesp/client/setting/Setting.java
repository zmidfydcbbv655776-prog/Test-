package dev.vaultesp.client.setting;

import java.util.function.BooleanSupplier;

/**
 * Base class for every value the ClickGUI, the config file and {@code /vaultesp} can touch.
 *
 * <p>The serialisation contract is deliberately string based: {@link #write()} and {@link #read(String)}
 * are used identically by {@code ConfigManager}, by the chat command and by the exported
 * {@code vaultesp.json}, so a config never drifts out of sync with the GUI.</p>
 *
 * @param <T> the value type
 */
public abstract class Setting<T> {

    private final String id;
    private final String name;
    private final T defaultValue;
    private T value;
    private String description = "";
    private BooleanSupplier visibility = () -> true;
    private BooleanSupplier availability = () -> true;

    protected Setting(String id, String name, T defaultValue) {
        this.id = id;
        this.name = name;
        this.defaultValue = defaultValue;
        this.value = defaultValue;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public T get() {
        return value;
    }

    public T getDefault() {
        return defaultValue;
    }

    public void set(T newValue) {
        this.value = newValue;
    }

    public void reset() {
        this.value = defaultValue;
    }

    public boolean isDefault() {
        return defaultValue == null ? value == null : defaultValue.equals(value);
    }

    /** Tooltip text shown in the ClickGUI. */
    public Setting<T> describe(String text) {
        this.description = text == null ? "" : text;
        return this;
    }

    /** Hides the row entirely when the condition fails (e.g. colour of a disabled block type). */
    public Setting<T> visibleWhen(BooleanSupplier condition) {
        this.visibility = condition == null ? () -> true : condition;
        return this;
    }

    /** Greys the row out but keeps it on screen, so the layout does not jump. */
    public Setting<T> availableWhen(BooleanSupplier condition) {
        this.availability = condition == null ? () -> true : condition;
        return this;
    }

    public boolean isVisible() {
        return visibility.getAsBoolean();
    }

    public boolean isAvailable() {
        return availability.getAsBoolean();
    }

    /** Serialises this value. Must never throw. */
    public abstract String write();

    /** Parses a serialised value. Invalid input must be ignored silently, never thrown. */
    public abstract void read(String raw);

    @Override
    public String toString() {
        return id + "=" + write();
    }
}