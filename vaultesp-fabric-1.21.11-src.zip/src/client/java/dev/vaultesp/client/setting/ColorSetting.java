package dev.vaultesp.client.setting;

/**
 * A packed ARGB colour with an optional rainbow cycle and adjustable cycle speed.
 *
 * <p>Serialised as {@code #AARRGGBB}, or {@code #AARRGGBB!0.40} when rainbow mode is on
 * (the suffix is the speed). Alpha is part of the value, which is what makes the
 * "transparency" setting per-colour instead of global.</p>
 */
public class ColorSetting extends Setting<Integer> {

    private boolean rainbow;
    private float rainbowSpeed = 0.40f;

    public ColorSetting(String id, String name, int argb) {
        super(id, name, argb);
    }

    /** The colour to draw this frame - honours rainbow cycling. */
    public int getArgb() {
        if (!rainbow) {
            return get();
        }
        float hue = (float) (((System.currentTimeMillis() * (double) rainbowSpeed) / 5200d) % 1d);
        return hsvToArgb(hue < 0 ? hue + 1f : hue, 0.78f, 1f, getAlpha());
    }

    public int getRed() {
        return (get() >> 16) & 0xFF;
    }

    public int getGreen() {
        return (get() >> 8) & 0xFF;
    }

    public int getBlue() {
        return get() & 0xFF;
    }

    public int getAlpha() {
        return (get() >>> 24) & 0xFF;
    }

    public void setRed(int red) {
        set(compose(red, getGreen(), getBlue(), getAlpha()));
    }

    public void setGreen(int green) {
        set(compose(getRed(), green, getBlue(), getAlpha()));
    }

    public void setBlue(int blue) {
        set(compose(getRed(), getGreen(), blue, getAlpha()));
    }

    public void setAlpha(int alpha) {
        set(compose(getRed(), getGreen(), getBlue(), alpha));
    }

    /** Alpha as 0..1 for the transparency slider. */
    public float getAlphaRatio() {
        return getAlpha() / 255f;
    }

    public void setAlphaRatio(float ratio) {
        setAlpha(Math.round(clamp01(ratio) * 255f));
    }

    public boolean isRainbow() {
        return rainbow;
    }

    public void setRainbow(boolean value) {
        this.rainbow = value;
    }

    public float getRainbowSpeed() {
        return rainbowSpeed;
    }

    public void setRainbowSpeed(float speed) {
        this.rainbowSpeed = Math.max(0.02f, Math.min(4f, speed));
    }

    /** Splits into {r, g, b, a} floats ready for a VertexConsumer#color call. */
    public float[] asFloats() {
        int argb = getArgb();
        return new float[]{
                ((argb >> 16) & 0xFF) / 255f,
                ((argb >> 8) & 0xFF) / 255f,
                (argb & 0xFF) / 255f,
                ((argb >>> 24) & 0xFF) / 255f
        };
    }

    public static int compose(int red, int green, int blue, int alpha) {
        return (clamp255(alpha) << 24) | (clamp255(red) << 16) | (clamp255(green) << 8) | clamp255(blue);
    }

    public static int withAlpha(int argb, int alpha) {
        return (clamp255(alpha) << 24) | (argb & 0x00FFFFFF);
    }

    public static float clamp01(float value) {
        return value < 0f ? 0f : Math.min(value, 1f);
    }

    private static int clamp255(int value) {
        return value < 0 ? 0 : Math.min(value, 255);
    }

    /** Hand rolled HSV -> ARGB so we never touch java.awt inside Minecraft. */
    public static int hsvToArgb(float hue, float saturation, float value, int alpha) {
        float h = (hue % 1f + 1f) % 1f * 6f;
        int i = (int) Math.floor(h);
        float f = h - i;
        float p = value * (1f - saturation);
        float q = value * (1f - saturation * f);
        float t = value * (1f - saturation * (1f - f));
        float r;
        float g;
        float b;
        switch (i % 6) {
            case 0 -> { r = value; g = t; b = p; }
            case 1 -> { r = q; g = value; b = p; }
            case 2 -> { r = p; g = value; b = t; }
            case 3 -> { r = p; g = q; b = value; }
            case 4 -> { r = t; g = p; b = value; }
            default -> { r = value; g = p; b = q; }
        }
        return compose(Math.round(r * 255f), Math.round(g * 255f), Math.round(b * 255f), alpha);
    }

    public static String toHex(int argb) {
        return String.format(java.util.Locale.ROOT, "#%08X", argb);
    }

    @Override
    public String write() {
        return rainbow
                ? String.format(java.util.Locale.ROOT, "#%08X!%.2f", get(), rainbowSpeed)
                : toHex(get());
    }

    @Override
    public void read(String raw) {
        if (raw == null) {
            return;
        }
        String text = raw.trim();
        int bang = text.indexOf('!');
        if (bang >= 0) {
            rainbow = true;
            try {
                setRainbowSpeed(Float.parseFloat(text.substring(bang + 1)));
            } catch (NumberFormatException ignored) {
                // keep previous speed
            }
            text = text.substring(0, bang);
        } else {
            rainbow = false;
        }
        if (text.startsWith("#")) {
            text = text.substring(1);
        }
        try {
            long parsed = Long.parseLong(text, 16);
            // Accept both RRGGBB and AARRGGBB.
            set((int) (text.length() <= 6 ? (0xFF000000L | parsed) : parsed));
        } catch (NumberFormatException ignored) {
            // leave the current colour untouched
        }
    }
}